package kr.ac.kpu.toms_manager;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.Toast;

public class check_clean extends AppCompatActivity {

    Button btn_submit;
    CheckBox ch11, ch12, ch13, ch21, ch22, ch23, ch31, ch32,ch33, ch41, ch42, ch43, ch51, ch52, ch53,
            ch61, ch62, ch63, ch71, ch72, ch73, ch81, ch82, ch83, ch91, ch92, ch93, ch101, ch102, ch103,ch111, ch112, ch113, ch121, ch122, ch123;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_clean);

        btn_submit = (Button)findViewById(R.id.btn_submit);
        //ch11 = (CheckBox)findViewById(R.id.ch11);

        btn_submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"작성완료",Toast.LENGTH_SHORT).show();
                finish();
            }
        });

    }
}