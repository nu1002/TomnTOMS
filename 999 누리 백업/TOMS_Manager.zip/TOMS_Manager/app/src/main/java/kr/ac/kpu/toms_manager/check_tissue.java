package kr.ac.kpu.toms_manager;

import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Objects;

public class check_tissue extends AppCompatActivity {

    TextView toilet_1, toilet_2, toilet_3, toilet_4;
    ImageButton refresh;
    //DB접근---------------------------------------------------------------------
    String url_1 = "http://www.waytech.kr/toms/app/tissue_state_1.php";
    String url_2 = "http://www.waytech.kr/toms/app/tissue_state_2.php";
    String url_3 = "http://www.waytech.kr/toms/app/tissue_state_3.php";
    String url_4 = "http://www.waytech.kr/toms/app/tissue_state_4.php";

    phpDown1 task_1;
    phpDown2 task_2;
    phpDown3 task_3;
    phpDown4 task_4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_tissue);
        toilet_1 = (TextView) findViewById(R.id.toilet_1);
        toilet_2 = (TextView) findViewById(R.id.toilet_2);
        toilet_3 = (TextView) findViewById(R.id.toilet_3);
        toilet_4 = (TextView) findViewById(R.id.toilet_4);

        //refresh = (ImageButton) findViewById(R.id.refresh);
//DB 접근---------------------------------------------------------------
        task_1 = new phpDown1();
        task_1.execute(url_1);

        task_2 = new phpDown2();
        task_2.execute(url_2);

        task_3 = new phpDown3();
        task_3.execute(url_3);

        task_4 = new phpDown4();
        task_4.execute(url_4);
//액티비티 새로----------------------------------------------------------
//        refresh.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Intent intent = getIntent();
//                finish();
//                startActivity(intent);
//            }
//        });


    }
//    public void restart(){
//        Intent intent = getIntent();
//        finish();
//        startActivity(intent);
//    }
    private class phpDown1 extends AsyncTask<String, Integer, String> {
        @Override
        protected String doInBackground(String... urls) {
            StringBuilder jsonHtml = new StringBuilder();
            try {
                // 연결 url 설정
                URL url = new URL(urls[0]);
                // 커넥션 객체 생성
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                // 연결되었으면.
                if (conn != null) {
                    conn.setConnectTimeout(10000);
                    conn.setUseCaches(false);
                    // 연결되었음 코드가 리턴되면.
                    if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                        for (; ; ) {
                            // 웹상에 보여지는 텍스트를 라인단위로 읽어 저장.
                            String line = br.readLine();
                            if (line == null) break;
                            // 저장된 텍스트 라인을 jsonHtml에 붙여넣음
                            jsonHtml.append(line + "\n");
                        }
                        br.close();
                    }
                    conn.disconnect();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return jsonHtml.toString();
        }

        protected void onPostExecute(String str) {
            //String txt1 = new String();
            try {
                JSONObject root = new JSONObject(str);
                //root라는 JSONObject 생성 ->str 값
                //String data = root.toString();
                String data = root.getString("state");

                //화장지 상태 값 : data  0(부족) 1(보통) 2(충분)
               if(Objects.equals("0", data)){
                    toilet_1.setText("부족");
                    toilet_1.setBackgroundColor(Color.parseColor("#AAABD3"));
                    //toilet_1.setTextColor(Color.parseColor("#c03546"));
                }else if(Objects.equals("1", data)){
                    toilet_1.setText("보통");
                    //toilet_1.setBackgroundColor(Color.parseColor("#c9d6de"));
                }else if(Objects.equals("2", data)){
                    toilet_1.setText("충분");
                  // toilet_1.setBackgroundColor(Color.parseColor("#c9d6de"));
               }
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }

    private class phpDown2 extends AsyncTask<String, Integer, String> {
        @Override
        protected String doInBackground(String... urls) {
            StringBuilder jsonHtml = new StringBuilder();
            try {
                // 연결 url 설정
                URL url = new URL(urls[0]);
                // 커넥션 객체 생성
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                // 연결되었으면.
                if (conn != null) {
                    conn.setConnectTimeout(10000);
                    conn.setUseCaches(false);
                    // 연결되었음 코드가 리턴되면.
                    if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                        for (; ; ) {
                            // 웹상에 보여지는 텍스트를 라인단위로 읽어 저장.
                            String line = br.readLine();
                            if (line == null) break;
                            // 저장된 텍스트 라인을 jsonHtml에 붙여넣음
                            jsonHtml.append(line + "\n");
                        }
                        br.close();
                    }
                    conn.disconnect();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return jsonHtml.toString();
        }

        protected void onPostExecute(String str) {
            //String txt1 = new String();
            try {
                JSONObject root = new JSONObject(str);
                //root라는 JSONObject 생성 ->str 값
                //String data = root.toString();
                String data = root.getString("state");

                if(Objects.equals("0", data)){
                    toilet_2.setText("부족");
                    toilet_2.setBackgroundColor(Color.parseColor("#AAABD3"));
                }else if(Objects.equals("1", data)){
                    toilet_2.setText("보통");
                    //toilet_2.setBackgroundColor(Color.parseColor("#c9d6de"));
                }else if(Objects.equals("2", data)){
                    toilet_2.setText("충분");
                    //toilet_2.setBackgroundColor(Color.parseColor("#c9d6de"));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }

    private class phpDown3 extends AsyncTask<String, Integer, String> {
        @Override
        protected String doInBackground(String... urls) {
            StringBuilder jsonHtml = new StringBuilder();
            try {
                // 연결 url 설정
                URL url = new URL(urls[0]);
                // 커넥션 객체 생성
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                // 연결되었으면.
                if (conn != null) {
                    conn.setConnectTimeout(10000);
                    conn.setUseCaches(false);
                    // 연결되었음 코드가 리턴되면.
                    if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                        for (; ; ) {
                            // 웹상에 보여지는 텍스트를 라인단위로 읽어 저장.
                            String line = br.readLine();
                            if (line == null) break;
                            // 저장된 텍스트 라인을 jsonHtml에 붙여넣음
                            jsonHtml.append(line + "\n");
                        }
                        br.close();
                    }
                    conn.disconnect();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return jsonHtml.toString();
        }

        protected void onPostExecute(String str) {
            //String txt1 = new String();
            try {
                JSONObject root = new JSONObject(str);
                //root라는 JSONObject 생성 ->str 값
                //String data = root.toString();
                String data = root.getString("state");

                if(Objects.equals("0", data)){
                    toilet_3.setText("부족");
                    toilet_3.setBackgroundColor(Color.parseColor("#AAABD3"));
                }else if(Objects.equals("1", data)){
                    toilet_3.setText("보통");
                    //toilet_3.setBackgroundColor(Color.parseColor("#c9d6de"));
                }else if(Objects.equals("2", data)){
                    toilet_3.setText("충분");
                    //toilet_3.setBackgroundColor(Color.parseColor("#c9d6de"));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    private class phpDown4 extends AsyncTask<String, Integer, String> {
        @Override
        protected String doInBackground(String... urls) {
            StringBuilder jsonHtml = new StringBuilder();
            try {
                // 연결 url 설정
                URL url = new URL(urls[0]);
                // 커넥션 객체 생성
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                // 연결되었으면.
                if (conn != null) {
                    conn.setConnectTimeout(10000);
                    conn.setUseCaches(false);
                    // 연결되었음 코드가 리턴되면.
                    if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                        for (; ; ) {
                            // 웹상에 보여지는 텍스트를 라인단위로 읽어 저장.
                            String line = br.readLine();
                            if (line == null) break;
                            // 저장된 텍스트 라인을 jsonHtml에 붙여넣음
                            jsonHtml.append(line + "\n");
                        }
                        br.close();
                    }
                    conn.disconnect();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return jsonHtml.toString();
        }

        protected void onPostExecute(String str) {
            //String txt1 = new String();
            try {
                JSONObject root = new JSONObject(str);
                //root라는 JSONObject 생성 ->str 값
                //String data = root.toString();
                String data = root.getString("state");

                if(Objects.equals("0", data)){
                    toilet_4.setText("부족");
                    toilet_4.setBackgroundColor(Color.parseColor("#AAABD3"));
                }else if(Objects.equals("1", data)){
                    toilet_4.setText("보통");
                    //toilet_4.setBackgroundColor(Color.parseColor("#c9d6de"));
                }else if(Objects.equals("2", data)){
                    toilet_4.setText("충분");
                    //toilet_4.setBackgroundColor(Color.parseColor("#c9d6de"));
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }
}
