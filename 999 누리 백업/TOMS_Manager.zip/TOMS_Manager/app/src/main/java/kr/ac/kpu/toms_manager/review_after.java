package kr.ac.kpu.toms_manager;

import android.content.Intent;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

public class review_after extends AppCompatActivity {
    Button write;
    ListView listView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review_after);

        write = (Button)findViewById(R.id.write);

        ListViewAdapter adapter;

        adapter = new ListViewAdapter();

        listView = (ListView)findViewById(R.id.ReviewListView);
        listView.setAdapter(adapter);

        Intent intent1 = getIntent();
        String title = intent1.getStringExtra("title");
        String body = intent1.getStringExtra("body");





        //adapter.addItem();
        //adapter.addItem(ContextCompat.getDrawable(this, R.drawable.profile_blank), "비누냄새좋다", "여기 비누 뭐예여? 어디꺼예여? ㅋㅋㅋ 손에서 향기나!");
        //adapter.addItem(ContextCompat.getDrawable(this, R.drawable.profile_blank), "좋네요", "화장실 사용하는 내내 좋은 향기가 나서 좋았어요! 감사합니다");
       // adapter.addItem(ContextCompat.getDrawable(this, R.drawable.profile_blank), "ㅇㅇ", "ㅇㅇ");







        write.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(review_after.this, write_review_Activity.class);
                startActivity(intent);

            }
        });


    }
}
