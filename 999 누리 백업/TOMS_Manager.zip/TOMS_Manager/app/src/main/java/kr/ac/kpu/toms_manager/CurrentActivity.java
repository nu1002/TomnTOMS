package kr.ac.kpu.toms_manager;

import android.Manifest;
import android.app.FragmentManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;


public class CurrentActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener, OnMapReadyCallback {

    TextView cleaner_id;
    CheckBox ch_sex_y, ch_sex_n, wheel_y, wheel_n;
    LatLng currentPosition;

    GoogleMap mMap;
    //LatLng SEOUL = new LatLng(37.56, 126.97);

    LatLng KPU = new LatLng(37.34105, 126.73316);
   // LatLng KPU_A = new LatLng(37.34044, 126.73283);
   // LatLng KPU_B = new LatLng(37.34025, 126.73316);
    LatLng KPU_C = new LatLng(37.34, 126.73386);
  //  LatLng KPU_D = new LatLng(37.33966, 126.73402);

    //TextView toilet_title, toilet_snippet, toilet_info, text;

    //GPS-------------------
    Button btnShowLocation;

    //private GoogleMap mMap;

    private final int PERMISSIONS_ACCESS_FINE_LOCATION = 1000;
    private final int PERMISSIONS_ACCESS_COARSE_LOCATION = 1001;
    private boolean isAccessFineLocation = false;
    private boolean isAccessCoarseLocation = false;
    private boolean isPermission = false;

    double latitude, longitude;

    // GPSTracker class
    private GpsInfo gps;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_current);

        //화장실 정보 내용
        cleaner_id = (TextView)findViewById(R.id.cleaner_id);
        ch_sex_y = (CheckBox)findViewById(R.id.ch_sex_y);
        ch_sex_n = (CheckBox)findViewById(R.id.ch_sex_n);
        wheel_y = (CheckBox)findViewById(R.id.wheel_y);
        wheel_n = (CheckBox)findViewById(R.id.wheel_n);

        ch_sex_y.setChecked(true);
        wheel_y.setChecked(true);
        cleaner_id.setText("공학관C동");

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.search);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

//생성생성생성
       // toilet_title = (TextView)findViewById(R.id.toilet_title);
        //toilet_snippet = (TextView)findViewById(R.id.toilet_snippet);
       // toilet_info = (TextView)findViewById(R.id.toilet_info);
      //  text = (TextView)findViewById(R.id.text);
        //GPS---------------
        btnShowLocation = (Button)findViewById(R.id.btn_gps_current);


//intent로 인트로 넘어가는거
        Intent intent = new Intent(this, IntroActivity.class);
        startActivity(intent);
        Log.v("제발","1 intent 1번");

        Intent intent1 = new Intent(this, menu_login.class);
        startActivity(intent1);
        Log.v("제발","1 intent 2번");


//지도 띄우는거
        FragmentManager fragmentManager = getFragmentManager();
        MapFragment mapFragment = (MapFragment)fragmentManager.findFragmentById(R.id.map);

        mapFragment.getMapAsync(this);


//GPS--------- 지도 등록-GPS-----------------------------------위에꺼 되어서 이거 안씀---------------
        //SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);

        //mapFragment.getMapAsync(this);

//버튼 클릭 - GPS 정보를 보여주기 위한 이벤트 클래스 등록
       btnShowLocation.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               // 권한 요청을 해야 함
               Log.v("제발","버튼1");
               if (!isPermission) {
                   callPermission();
                   return;

               }
               Log.v("제발","버튼2");
               gps = new GpsInfo(CurrentActivity.this);
               // GPS 사용유무 가져오기
               if (gps.isGetLocation()) {
                   Log.v("제발","버튼3");

                   latitude = gps.getLatitude();
                   longitude = gps.getLongitude();

                   currentPosition = new LatLng(latitude, longitude);

                   Log.v("제발","버튼4");

                   //Toast.makeText(getApplicationContext(),"당신의 위치 - \n위도: " + latitude + "\n경도: " + longitude,
                     //      Toast.LENGTH_LONG).show();
               } else {
                   // GPS 를 사용할수 없으므로
                   Log.v("제발","버튼5");

                   gps.showSettingsAlert();

               }
           }
       });
       callPermission();  // 권한 요청을 해야 함
    }

//네비게이터 기본 설정 절대 건들지말기-------------------------------------------------------------------------------------
    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.current, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.check_info) {
            Intent intent = new Intent(this,menu_check.class);
            startActivity(intent);
        } else if (id == R.id.infor_current) {
            Intent intent = new Intent(this,menu_infor.class);
            startActivity(intent);
        } else if (id == R.id.qa_current) {
            Intent intent = new Intent(this, menu_qa.class);
            startActivity(intent);
        }
        else if (id == R.id.check_gar) {
            Intent intent = new Intent(this, check_gar.class);
            startActivity(intent);
        }
        else if (id == R.id.check_tissue) {
            Intent intent = new Intent(this, check_tissue.class);
            startActivity(intent);
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
//---------------------------------------------------------------------------------------------------------

    public void onMapReady(GoogleMap googleMap) {

        mMap = googleMap;

        //mMap.setOnMarkerClickListener(this);
        //LatLng SEOUL = new LatLng(37.56, 126.97);

        MarkerOptions markerOptions_KPU = new MarkerOptions();
        markerOptions_KPU.position(KPU).title("한국산업기술대학교")
                .snippet("현재 내 위치").icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE));
        mMap.addMarker(markerOptions_KPU); //이게 있어야 마커 표시 ㅇㅇ

        mMap.moveCamera(CameraUpdateFactory.newLatLng(KPU)); //(new LatLng(37.52487, 126.92723)) // 카메라를 위치로 옮긴다.
        mMap.animateCamera(CameraUpdateFactory.zoomTo(18));
        Log.v("제발","1000번");

//-----------------여기서부터 추가 마커들
        /*
        MarkerOptions markerOptions_A = new MarkerOptions();
        markerOptions_A.position(KPU_A).title("공학관A동").snippet("(1/2)").alpha(0.3f);
        mMap.addMarker(markerOptions_A);


        MarkerOptions markerOptions_B = new MarkerOptions();
        markerOptions_B.position(KPU_B).title("공학관B동").snippet("(2/2)").alpha(0.5f);
        mMap.addMarker(markerOptions_B);
        */

        MarkerOptions markerOptions_C = new MarkerOptions();
        markerOptions_C.position(KPU_C).title("공학관C동").snippet("(0/2)");
        mMap.addMarker(markerOptions_C);

        /*
        MarkerOptions markerOptions_D = new MarkerOptions();
        markerOptions_D.position(KPU_D).title("공학관D동").snippet("(0/2)").alpha(0.5f);
        mMap.addMarker(markerOptions_D);
        */

    }
/*

    @Override
    public boolean onMarkerClick(final Marker marker) {
        toilet_title.setText(marker.getTitle());
        Log.v("제발","1001번");
        toilet_snippet.setText(marker.getSnippet());
        Log.v("제발","1002번");

        toilet_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CurrentActivity.this, Current_toiletActivity.class);
                intent.putExtra("data",marker.getTitle());
                intent.putExtra("seat",marker.getSnippet());
                intent.putExtra("id",marker.getId());
                startActivity(intent);
            }
        });

        return false;
    }
*/
    //GPS 권한 요청
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == PERMISSIONS_ACCESS_FINE_LOCATION
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

            isAccessFineLocation = true;

        } else if (requestCode == PERMISSIONS_ACCESS_COARSE_LOCATION
                && grantResults[0] == PackageManager.PERMISSION_GRANTED){

            isAccessCoarseLocation = true;
        }

        if (isAccessFineLocation && isAccessCoarseLocation) {
            isPermission = true;
        }
    }

    // 전화번호 권한 요청
    private void callPermission() {
        // Check the SDK version and whether the permission is already granted or not.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            requestPermissions(
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    PERMISSIONS_ACCESS_FINE_LOCATION);

        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED){

            requestPermissions(
                    new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},
                    PERMISSIONS_ACCESS_COARSE_LOCATION);
        } else {
            isPermission = true;
        }
    }


}