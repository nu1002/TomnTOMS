package kr.ac.kpu.toms_manager;

import android.graphics.drawable.Drawable;
import android.widget.CheckBox;

public class ListViewItem  {

    Drawable num;
    String checking;
    String state;


    public void setNum(int num){
        num = num;
    }
    public void setChecking(String checking){
        checking = checking;
    }
    public void setState(CheckBox state){
        state = state;
    }


    public Drawable getIcon() {
        return this.num;
    }

    public String getTitle() {
        return this.checking;
    }

    public String getBody() {
        return this.state;
    }

}
