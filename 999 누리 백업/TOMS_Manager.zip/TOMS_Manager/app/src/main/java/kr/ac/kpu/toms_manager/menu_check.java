package kr.ac.kpu.toms_manager;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class menu_check extends AppCompatActivity {

    RelativeLayout clean, fac;
    Button btn_check_clean, btn_check_fac;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_check);

        //getID = (TextView)findViewById(R.id.getID);
        clean = (RelativeLayout)findViewById(R.id.clean);
        fac = (RelativeLayout)findViewById(R.id.fac);

        btn_check_clean = (Button)findViewById(R.id.btn_check_clean);
        btn_check_fac = (Button)findViewById(R.id.btn_check_fac);

        clean.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(menu_check.this, check_clean.class);
                startActivity(intent1);
            }
        });

        btn_check_clean.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(menu_check.this, check_clean.class);
                startActivity(intent1);
            }
        });

        fac.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2 = new Intent(menu_check.this, check_fac.class);
                startActivity(intent2);
            }
        });

        btn_check_fac.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent2 = new Intent(menu_check.this, check_fac.class);
                startActivity(intent2);
            }
        });
    }
}
