package kr.ac.kpu.toms_manager;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.RelativeLayout;
import android.widget.TextView;

public class menu_check extends AppCompatActivity {

    TextView getID;
    RelativeLayout clean, fac, gar, tissue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_check);

        //getID = (TextView)findViewById(R.id.getID);
        clean = (RelativeLayout)findViewById(R.id.clean);
        fac = (RelativeLayout)findViewById(R.id.fac);

        if(menu_log.ID != null) {
            getID.setText(menu_log.ID);
        }

        clean.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(menu_check.this, check_clean.class);
                startActivity(intent);
            }
        });
        fac.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(menu_check.this, check_fac.class);
                startActivity(intent);
            }
        });





    }
}
