package kr.ac.kpu.toms_manager;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class write_review_Activity extends AppCompatActivity {
    Button write_send;
    EditText write_title, write_body;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_write_review);

        write_send = (Button)findViewById(R.id.write_send);
        write_title = (EditText)findViewById(R.id.write_title);
        write_body = (EditText)findViewById(R.id.write_body);

        write_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent1 = new Intent(write_review_Activity.this, review_after.class);
                intent1.putExtra("title",write_title.getText());
                intent1.putExtra("body",write_body.getText());
                startActivity(intent1);
            }
        });




    }
}
