package kr.ac.kpu.toms_manager;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.sql.BatchUpdateException;

public class check_gar_write extends AppCompatActivity {
    EditText input_1, input_2, input_3;
    String input_1_s, input_2_s, input_3_s;
    Button btn_add;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_gar_write);

        input_1 = (EditText)findViewById(R.id.input_1);
        input_2 = (EditText)findViewById(R.id.input_2);
        input_3 = (EditText)findViewById(R.id.input_3);

        btn_add = (Button)findViewById(R.id.btn_add);

        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //입력된 값을 String으로 넣음
                input_1_s = input_1.getText().toString();
                input_2_s = input_2.getText().toString();
                input_3_s = input_3.getText().toString();

                //DB에 등록
                registDB(input_1_s, input_2_s, input_3_s);
                finish();
            }
        });
    }

    private void registDB(String input_1_s, String input_2_s, String input_3_s) {
        class InsertData extends AsyncTask<String, Void, String> {
            ProgressDialog loading;
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(check_gar_write.this, "Please Wait", null, true, true);
            }
            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                Toast.makeText(getApplicationContext(), s, Toast.LENGTH_LONG).show();
            }
            @Override
            protected String doInBackground(String... params) {
                try {
                    //각 값의 변수 설정
                    String input_1_s = (String) params[0];
                    String input_2_s = (String) params[1];
                    String input_3_s = (String) params[2];
                    Log.v("제발", "변수 ㅇㅋ");

                    //연결하고 값 넣기
                    String link = "http://www.waytech.kr/toms/app/gar_insert.php";
                    String data = URLEncoder.encode("input_1_s", "UTF-8") + "=" + URLEncoder.encode(input_1_s, "UTF-8");
                    data += "&" + URLEncoder.encode("input_2_s", "UTF-8") + "=" + URLEncoder.encode(input_2_s, "UTF-8");
                    data += "&" + URLEncoder.encode("input_3_s", "UTF-8") + "=" + URLEncoder.encode(input_3_s, "UTF-8");
                    Log.v("제발", "값넣기 ㅇㅋ");
                    //서버연결
                    URL url = new URL(link);
                    URLConnection conn = url.openConnection();

                    conn.setDoOutput(true);
                    OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());

                    wr.write(data);
                    wr.flush();

                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                    StringBuilder sb = new StringBuilder();
                    String line = null;
                    Log.v("제발", "서버연결 ㅇㅋ");
                    // Read Server Response
                    while ((line = reader.readLine()) != null) {
                        sb.append(line);
                        break;
                    }
                    return sb.toString();
                } catch (Exception e) {
                    return new String("Exception: " + e.getMessage());
                }
            }
        }
        //최종
        InsertData task = new InsertData();
        Log.v("제발","1111 ㅇㅋ");
        task.execute(input_1_s, input_2_s, input_3_s);
        Log.v("제발","2222 ㅇㅋ");
    }
}
