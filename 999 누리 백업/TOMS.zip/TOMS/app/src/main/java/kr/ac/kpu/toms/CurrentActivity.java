package kr.ac.kpu.toms;

import android.Manifest;
import android.app.FragmentManager;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;


public class CurrentActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener, OnMapReadyCallback, GoogleMap.OnMarkerClickListener {

    //주변위치 필요 변수
    //List<Marker> previous_marker = null;
    //List<Place> places=null;
    LatLng currentPosition;
    //private GoogleMap mGoogleMap = null;

    GoogleMap mMap;
    //LatLng SEOUL = new LatLng(37.56, 126.97);

    LatLng KPU = new LatLng(37.34028, 126.7335);
    LatLng KPU_A = new LatLng(37.34044, 126.73283);
    LatLng KPU_B = new LatLng(37.34025, 126.73316);
    LatLng KPU_C = new LatLng(37.34, 126.73386);
    LatLng KPU_D = new LatLng(37.33966, 126.73402);

    TextView toilet_title, toilet_snippet, toilet_info, text;

    //GPS-------------------
    Button btnShowLocation;

    //private GoogleMap mMap;

    private final int PERMISSIONS_ACCESS_FINE_LOCATION = 1000;
    private final int PERMISSIONS_ACCESS_COARSE_LOCATION = 1001;
    private boolean isAccessFineLocation = false;
    private boolean isAccessCoarseLocation = false;
    private boolean isPermission = false;

    double latitude, longitude;

    // GPSTracker class
    private GpsInfo gps;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_current);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.search);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

//생성생성생성
        toilet_title = (TextView)findViewById(R.id.toilet_title);
        toilet_snippet = (TextView)findViewById(R.id.toilet_snippet);
        toilet_info = (TextView)findViewById(R.id.toilet_info);
        text = (TextView)findViewById(R.id.text);
        //GPS---------------
        btnShowLocation = (Button)findViewById(R.id.btn_gps_current);


//intent로 인트로 넘어가는거
        Intent intent = new Intent(this, IntroActivity.class);
        startActivity(intent);


//지도 띄우는거
        FragmentManager fragmentManager = getFragmentManager();
        MapFragment mapFragment = (MapFragment)fragmentManager.findFragmentById(R.id.map);

        mapFragment.getMapAsync(this);


//GPS--------- 지도 등록-GPS-----------------------------------위에꺼 되어서 이거 안씀---------------
        //SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);

        //mapFragment.getMapAsync(this);
//-----------------------------------------------------------------------------------------------------------------------

        /*
        //리스트뷰
        ListView listView;
        ListViewAdapter adapter;

        adapter = new ListViewAdapter();

        listView = (ListView)findViewById(R.id.listvieww);
        listView.setAdapter(adapter);

        //adapter.addItem();

        adapter.addItem(ContextCompat.getDrawable(this, R.drawable.search_current), "<한국산업기술대학교 A동>", "현재 사용률 : (1/2)");
        adapter.addItem(ContextCompat.getDrawable(this, R.drawable.search_current), "<한국산업기술대학교 B동>", "현재 사용률 : (2/2)");
        adapter.addItem(ContextCompat.getDrawable(this, R.drawable.search_current), "<한국산업기술대학교 C동>", "현재 사용률 : (0/2)");
        adapter.addItem(ContextCompat.getDrawable(this, R.drawable.search_current), "<한국산업기술대학교 D동>", "현재 사용률 : (0/2)");

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                ListViewItem item = (ListViewItem)parent.getItemAtPosition(position);

                Intent intent = new Intent(CurrentActivity.this, Current_toiletActivity.class);

                startActivity(intent);
            }
        });*/



//주변위치 띄우기

        /*
        previous_marker = new ArrayList<Marker>();
        Button button = (Button)findViewById(R.id.around_test_bt);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                printMarkers(map);

            }

        });
        */

//버튼 누르면 login, join
        //TextView user_id = (TextView)findViewById(R.id.user_id);
       /* Button login = (Button)findViewById(R.id.login);
        Button join = (Button)findViewById(R.id.join);

        //user_id.setText(); -회원 id를 띄우기
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Intent intent = new Intent(CurrentActivity.this,MainActivity.class);
                //startActivity(intent);
            }
        });
        join.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Intent intent = new Intent(CurrentActivity.this, MainActivity.class);
                //startActivity(intent);
            }
        });

*/
       //버튼 클릭 - GPS 정보를 보여주기 위한 이벤트 클래스 등록
       btnShowLocation.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               // 권한 요청을 해야 함
               Log.v("제발","버튼1");
               MarkerOptions markerOptions_A = new MarkerOptions();
               markerOptions_A.position(KPU_A).title("공학관A동").snippet("(3/4)");
               mMap.addMarker(markerOptions_A);


               MarkerOptions markerOptions_B = new MarkerOptions();
               markerOptions_B.position(KPU_B).title("공학관B동").snippet("(2/4)");
               mMap.addMarker(markerOptions_B);

               MarkerOptions markerOptions_C = new MarkerOptions();
               markerOptions_C.position(KPU_C).title("공학관C동").snippet("(1/4)");
               mMap.addMarker(markerOptions_C);

               MarkerOptions markerOptions_D = new MarkerOptions();
               markerOptions_D.position(KPU_D).title("공학관D동").snippet("(0/4)");
               mMap.addMarker(markerOptions_D);

               if (!isPermission) {
                   callPermission();
                   return;
               }
               Log.v("제발","버튼2");
               gps = new GpsInfo(CurrentActivity.this);
               // GPS 사용유무 가져오기
               if (gps.isGetLocation()) {
                   Log.v("제발","버튼3");

                   latitude = gps.getLatitude();
                   longitude = gps.getLongitude();

                   currentPosition = new LatLng(latitude, longitude);

                   Log.v("제발","버튼4");

                   //Toast.makeText(getApplicationContext(),"당신의 위치 - \n위도: " + latitude + "\n경도: " + longitude, Toast.LENGTH_LONG).show();
               } else {
                   // GPS 를 사용할수 없으므로
                   Log.v("제발","버튼5");

                   gps.showSettingsAlert();

               }
           }
       });
       callPermission();  // 권한 요청을 해야 함
    }

//네비게이터 기본 설정 절대 건들지말기-------------------------------------------------------------------------------------
    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.current, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        /*
        TextView user_id = (TextView)findViewById(R.id.user_id);
        Button login = (Button)findViewById(R.id.login);
        Button join = (Button)findViewById(R.id.join);

        /*
        //user_id.setText(); -회원 id를 띄우기
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CurrentActivity.this,MainActivity.class);
                startActivity(intent);
            }
        });
        */


        if (id == R.id.write_current) {
            //Toast.makeText(this, "눌렀당", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(this,menu_write.class);
            startActivity(intent);
            //finish();
        } else if (id == R.id.review_current) {
            Intent intent = new Intent(this,menu_review.class);
            startActivity(intent);
        } else if (id == R.id.wrong_current) {
            Intent intent = new Intent(this,menu_wrong.class);
            startActivity(intent);
        } else if (id == R.id.qa_current) {
            Intent intent = new Intent(this,menu_qa.class);
            startActivity(intent);
        } else if (id == R.id.infor_current) {
            Intent intent = new Intent(this,menu_infor.class);
            startActivity(intent);
        } else if (id == R.id.login_current) {
            Intent intent = new Intent(this, menu_login.class);
            startActivity(intent);
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
//---------------------------------------------------------------------------------------------------------

    public void onMapReady(GoogleMap googleMap) {

        mMap = googleMap;

        mMap.setOnMarkerClickListener(this);
        //LatLng SEOUL = new LatLng(37.56, 126.97);

        MarkerOptions markerOptions_KPU = new MarkerOptions();
        markerOptions_KPU.position(KPU).title("한국산업기술대학교")
                .snippet("현재 내 위치").icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE));
        mMap.addMarker(markerOptions_KPU); //이게 있어야 마커 표시 ㅇㅇ

        mMap.moveCamera(CameraUpdateFactory.newLatLng(KPU)); //(new LatLng(37.52487, 126.92723)) // 카메라를 위치로 옮긴다.
        mMap.animateCamera(CameraUpdateFactory.zoomTo(17));
        Log.v("제발","1000번");

//-----------------여기서부터 추가 마커들


    }

    @Override
    public boolean onMarkerClick(final Marker marker) {
        toilet_title.setText(marker.getTitle());
        Log.v("제발","1001번");
        toilet_snippet.setText(marker.getSnippet());
        Log.v("제발","1002번");

        toilet_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CurrentActivity.this, Current_toiletActivity.class);
                intent.putExtra("data",marker.getTitle());
                intent.putExtra("seat",marker.getSnippet());
                intent.putExtra("id",marker.getId());
                startActivity(intent);
            }
        });

        return false;
    }


/*
//주변위치 받아오기----------------------------------------------------------------------------------
    @Override
    public void onPointerCaptureChanged(boolean hasCapture) {

    }

    @Override
    public void onPlacesFailure(PlacesException e) {

    }

    @Override
    public void onPlacesStart() {

    }

    @Override
    public void onPlacesSuccess(final List<Place> places) {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                for(noman.googleplaces.Place place : places) {
                    Log.v("제발","1번");

                    LatLng latLng = new LatLng(place.getLatitude(), place.getLongitude());
                    Log.v("제발","2번");

                    LatLng state = latLng;

                    result.setText(state.toString());

                    // String markerSnippet = getCurrentAddress(latLng);

                    MarkerOptions markerOptions = new MarkerOptions();
                    Log.v("제발","3번");

                    markerOptions.position(latLng);
                    Log.v("제발","4번");

                    markerOptions.title("서울");
                    Log.v("제발","5번");

                    markerOptions.snippet("한국의 수도");
                    Log.v("제발","6번");

                    //mGoogleMap.addMarker(markerOptions);


                    Marker item = mGoogleMap.addMarker(markerOptions);
                    Log.v("제발","7번");

                    previous_marker.add(item);
                    Log.v("제발","8번");
                }
                HashSet<Marker> hashSet = new HashSet<Marker>();
                hashSet.addAll(previous_marker);
                previous_marker.clear();
                previous_marker.addAll(hashSet);
            }
        });
    }

    public void showPlaceInformation(GoogleMap map) { //location currentPosition
        Log.v("제발","11번");

        LatLng SEOULSTATION = new LatLng(37.555856, 126.969682);

        MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.position(SEOULSTATION);
        markerOptions.title("서울역");
        markerOptions.snippet("1");
        map.addMarker(markerOptions); //이게 있어야 마커 표시 ㅇㅇ

        map.moveCamera(CameraUpdateFactory.newLatLng(SEOULSTATION));
        map.animateCamera(CameraUpdateFactory.zoomTo(15));
        Log.v("제발","12번");

        //mGoogleMap.clear();
        Log.v("제발","12번");

        if (previous_marker != null)
            Log.v("제발","13번");
            previous_marker.clear();//지역정보 마커 클리어
        Log.v("제발","14번");

        new NRPlaces.Builder()
                .listener(CurrentActivity.this)
                .key("AIzaSyDBWB0tPMiG1msZpxoffwHipSef4-WhtUg")
                .latlng(location.latitude, location.longitude)//현재 위치
                .radius(500) //500 미터 내에서 검색
                .type(PlaceType.RESTAURANT) //음식점
                .build()
                .execute();
        Log.v("제발","15번");


    }
    */
/*
    <Button
        android:layout_width="match_parent"
                android:layout_height="wrap_content"
                android:id="@+id/around_test_bt"
                android:layout_below="@+id/map"
                android:text="장소검색"/>
    public void printMarkers(GoogleMap map) {
        Log.v("제발","버튼1");
        for (int idx = 1; idx < 10; idx++) {
            // 1. 마커 옵션 설정 (만드는 과정)
            Log.v("제발","버튼2");
            MarkerOptions near_makerOptions = new MarkerOptions();
            Log.v("제발","버튼3");
            near_makerOptions // LatLng에 대한 어레이를 만들어서 이용할 수도 있다.
                    .position(new LatLng(37.34028 + idx, 126.7335))
                    .title("마커" + idx); // 타이틀.

            Log.v("제발","버튼4");
            // 2. 마커 생성 (마커를 나타냄)
            //map.addMarker(near_makerOptions);
            //왜 addMarker가 되지 않는 것인가..왜.어쟤서...뭐때문에...

        }
    }
*/

    //GPS 권한 요청
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        if (requestCode == PERMISSIONS_ACCESS_FINE_LOCATION
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

            isAccessFineLocation = true;

        } else if (requestCode == PERMISSIONS_ACCESS_COARSE_LOCATION
                && grantResults[0] == PackageManager.PERMISSION_GRANTED){

            isAccessCoarseLocation = true;
        }

        if (isAccessFineLocation && isAccessCoarseLocation) {
            isPermission = true;
        }
    }

    // 전화번호 권한 요청
    private void callPermission() {
        // Check the SDK version and whether the permission is already granted or not.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            requestPermissions(
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                    PERMISSIONS_ACCESS_FINE_LOCATION);

        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION)
                != PackageManager.PERMISSION_GRANTED){

            requestPermissions(
                    new String[]{Manifest.permission.ACCESS_COARSE_LOCATION},
                    PERMISSIONS_ACCESS_COARSE_LOCATION);
        } else {
            isPermission = true;
        }
    }


}