package kr.ac.kpu.toms;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

public class login_signup extends AppCompatActivity {

    EditText input_ID, input_Nick, input_PW, input_PW_check;
    String String_ID, String_Nick, String_PW, String_PW_check;
    Button button_signup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_signup);

        input_ID = (EditText) findViewById(R.id.input_ID);
        input_Nick = (EditText) findViewById(R.id.input_Nick);
        input_PW = (EditText) findViewById(R.id.input_PW);
        input_PW_check = (EditText) findViewById(R.id.input_PW_check);
        button_signup = (Button) findViewById(R.id.button_signup);

        button_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //입력된 값을 String으로 넣음
                String_ID = input_ID.getText().toString();
                String_Nick = input_Nick.getText().toString();
                String_PW = input_PW.getText().toString();
                String_PW_check = input_PW_check.getText().toString();

                Log.v("제발","패스워드 확인");
                //패스워드 확인
                if(String_PW.equals(String_PW_check)){
                    registDB(String_ID, String_PW, String_Nick);
                    Log.v("제발","regist DB 생성");
                    //Toast.makeText(getApplication(), "가입완료", Toast.LENGTH_SHORT).show();
                    finish();
                } else {
                    Toast.makeText(getApplication(), "비밀번호가 다릅니다.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void registDB(String Id, String Pw, String Nick) {
        class InsertData extends AsyncTask<String, Void, String> {
            ProgressDialog loading;
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(login_signup.this, "Please Wait", null, true, true);
            }
            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                Toast.makeText(getApplicationContext(), s, Toast.LENGTH_LONG).show();
            }
            @Override
            protected String doInBackground(String... params) {
                try {
                    //각 값의 변수 설정
                    String Id = (String) params[0];
                    String Pw = (String) params[1];
                    String Nick = (String) params[2];

                    //연결하고 값 넣기
                    String link = "http://www.waytech.kr/toms/app/join.php";
                    String data = URLEncoder.encode("Id", "UTF-8") + "=" + URLEncoder.encode(Id, "UTF-8");
                    data += "&" + URLEncoder.encode("Pw", "UTF-8") + "=" + URLEncoder.encode(Pw, "UTF-8");
                    data += "&" + URLEncoder.encode("Nick", "UTF-8") + "=" + URLEncoder.encode(Nick, "UTF-8");


                    //서버연결
                    URL url = new URL(link);
                    URLConnection conn = url.openConnection();

                    conn.setDoOutput(true);
                    OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());

                    wr.write(data);
                    wr.flush();

                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                    StringBuilder sb = new StringBuilder();
                    String line = null;

                    // Read Server Response
                    while ((line = reader.readLine()) != null) {
                        sb.append(line);
                        break;
                    }
                    return sb.toString();
                } catch (Exception e) {
                    return new String("Exception: " + e.getMessage());
                }
            }
        }
        //최종
        InsertData task = new InsertData();
        task.execute(Id, Pw, Nick);
    }
}


