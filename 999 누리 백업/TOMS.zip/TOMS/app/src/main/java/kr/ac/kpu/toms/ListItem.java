package kr.ac.kpu.toms;

/** 테스트용
 * Created by 누리 on 2018-04-30.
 */

public class ListItem {
    private String[] mData;

    public ListItem(String[] data) {
        mData=data;
    }

    public ListItem(String txt1, String txt2) {
        mData=new String[2];
        mData[0]=txt1;
        mData[1]=txt2;
    }
    public String[] getData() {
        return mData;
    }
    public String getData(int index) {
        return mData[index];
    }
    public void setData(String[] data) {
        mData = data;
    }
}
