package kr.ac.kpu.toms;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.ViewFlipper;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.ResponseHandler;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.BasicResponseHandler;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;

import java.util.ArrayList;
import java.util.List;


public class menu_login extends AppCompatActivity {

    public static String ID;
                         //="user01";
    public static String PW;

    EditText input_ID, input_PW;
    Button button_signin, button_signup;

    HttpPost httppost;
    HttpResponse response;
    HttpClient httpclient;
    List<NameValuePair> nameValuePairs;
    ProgressDialog dialog = null;

    StringBuffer buffer;
    ViewFlipper Vf;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_login);

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        input_ID=(EditText) findViewById(R.id.input_ID);
        input_PW=(EditText)findViewById(R.id.input_PW);

        button_signin=(Button)findViewById(R.id.button_signin);
        button_signup=(Button)findViewById(R.id.button_signup);

        //회원가입 activity로 이동
        button_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(menu_login.this, login_signup.class);
                //intent.putExtra("ID",input_ID.getText());
                startActivity(intent);
            }
        });

        //로그인 activity로 이동
        button_signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dialog = ProgressDialog.show(menu_login.this, "",
                        "Validating user...", true);
                new Thread(new Runnable() {
                    public void run() {
                        login();
                    }
                }).start();
                finish();
            }
        });


/*

        button_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                string_ID = input_ID.getText().toString();
                string_PW = input_PW.getText().toString();
                string_PW_check = input_PW_check.getText().toString();

                if(string_PW.equals(string_PW_check)) {
                    //패스워드 확인 = 맞음
                    registDB rdb = new registDB();
                    rdb.execute();
                } else {
                    //패스워드 확인 = 틀림

                }

            }
        });

*/

    }
/*
    public class registDB extends AsyncTask<Void, Integer, Void> {

        @Override
        protected Void doInBackground(Void... unused) {

// 인풋 파라메터값 생성
            String param = "u_id=" + string_ID + "&u_pw=" + string_PW + "";
            try {
// 서버연결
                URL url = new URL(
                        "http://waytech.kr/toms/app/join.php");
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                conn.setRequestMethod("POST");
                conn.setDoInput(true);
                conn.connect();

// 안드로이드 -> 서버 파라메터값 전달
                OutputStream outs = conn.getOutputStream();
                outs.write(param.getBytes("UTF-8"));
                outs.flush();
                outs.close();

// 서버 -> 안드로이드 파라메터값 전달
                InputStream is = null;
                BufferedReader in = null;
                String data = "";

                is = conn.getInputStream();
                in = new BufferedReader(new InputStreamReader(is), 8 * 1024);
                String line = null;
                StringBuffer buff = new StringBuffer();
                while ( ( line = in.readLine() ) != null )
                {
                    buff.append(line + "\n");
                }
                data = buff.toString().trim();
                Log.e("RECV DATA",data);

            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;
        }

    }*/

    void login() {
        try {
            httpclient = new DefaultHttpClient();
            httppost = new HttpPost("http://www.waytech.kr/toms/app/login.php");
            nameValuePairs = new ArrayList<NameValuePair>(2);
            nameValuePairs.add(new BasicNameValuePair("Id", input_ID.getText().toString()));
            nameValuePairs.add(new BasicNameValuePair("Pw", input_PW.getText().toString()));
            httppost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
            response = httpclient.execute(httppost);
            ResponseHandler<String> responseHandler = new BasicResponseHandler();
            final String response = httpclient.execute(httppost, responseHandler);
            System.out.println("Response : " + response);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    //tv.setText("Response from PHP : " + response);
                    dialog.dismiss();
                }
            });

            if (response.equalsIgnoreCase("User Found")) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        ID = input_ID.toString();
                        PW = input_PW.toString();
                        Toast.makeText(menu_login.this, "Login Success", Toast.LENGTH_SHORT).show();
                    }
                });

            } else {
                Toast.makeText(menu_login.this, "Login Fail", Toast.LENGTH_SHORT).show();
            }
        }
        catch(Exception e)
        {
            dialog.dismiss();
            System.out.println("Exception : " + e.getMessage());
        }

    }
}
