package kr.ac.kpu.toms;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

public class write_wrong_Activity extends AppCompatActivity {
    Button write_send;
    EditText write_title, write_content;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_write_wrong);

        write_send = (Button)findViewById(R.id.write_send);
        write_title = (EditText)findViewById(R.id.write_title);
        write_content = (EditText)findViewById(R.id.write_body);
/*
        write_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(write_wrong_Activity.this, menu_wrong.class);
                intent.putExtra("title",write_title.getText());
                intent.putExtra("body",write_body.getText());
                startActivity(intent);
            }
        });
*/
    }
    public void insert(View view) {
        String title = write_title.getText().toString();
        String content = write_content.getText().toString();

        insertoToDatabase(title, content);
    }

    private void insertoToDatabase(String title, String content) {
        class InsertData extends AsyncTask<String, Void, String> {
            ProgressDialog loading;

            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(write_wrong_Activity.this, "Please Wait", null, true, true);
            }

            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                Toast.makeText(getApplicationContext(), s, Toast.LENGTH_LONG).show();
            }

            @Override
            protected String doInBackground(String... params) {

                try {
                    String title = (String) params[0];
                    String content = (String) params[1];

                    //review_insert.php에 다른 변수정보 있어야 하느지 없어도 되는지 확인하기
                    String link = "http://www.waytech.kr/toms/app/wrong_insert.php";
                    String data = URLEncoder.encode("title", "UTF-8") + "=" + URLEncoder.encode(title, "UTF-8");
                    data += "&" + URLEncoder.encode("content", "UTF-8") + "=" + URLEncoder.encode(content, "UTF-8");

                    URL url = new URL(link);
                    URLConnection conn = url.openConnection();

                    conn.setDoOutput(true);
                    OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());

                    wr.write(data);
                    wr.flush();

                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                    StringBuilder sb = new StringBuilder();
                    String line = null;

                    // Read Server Response
                    while ((line = reader.readLine()) != null) {
                        sb.append(line);
                        break;
                    }
                    return sb.toString();

                } catch (Exception e) {
                    //등록 실패 시 출력
                    return new String("Exception: " + e.getMessage());
                }
            }
        }
        InsertData task = new InsertData();
        task.execute(title, content);
        finish();
    }
}
