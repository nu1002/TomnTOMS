package kr.ac.kpu.toms;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

public class write_wrong_Activity extends AppCompatActivity {

    EditText input_write_title, input_write_content;
    String String_write_title, String_write_content;
    Button btn_write_send;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_write_wrong);

        btn_write_send = (Button)findViewById(R.id.write_send);
        input_write_title = (EditText)findViewById(R.id.write_title);
        input_write_content = (EditText)findViewById(R.id.write_body);

        btn_write_send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //입력된 값을 String으로 넣음
                String_write_title = input_write_title.getText().toString();
                String_write_content = input_write_content.getText().toString();

                //DB에 등록
                registDB(String_write_title, String_write_content);

                //Toast.makeText(getApplicationContext(),"등록완료",Toast.LENGTH_SHORT).show();
                finish();
            }
        });

    }
    private void registDB(String wrong_title, String wrong_content) {
        class InsertData extends AsyncTask<String, Void, String> {
            ProgressDialog loading;
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
                loading = ProgressDialog.show(write_wrong_Activity.this, "Please Wait", null, true, true);
            }
            @Override
            protected void onPostExecute(String s) {
                super.onPostExecute(s);
                loading.dismiss();
                Toast.makeText(getApplicationContext(), s, Toast.LENGTH_LONG).show();
            }
            @Override
            protected String doInBackground(String... params) {
                try {
                    //각 값의 변수 설정
                    String wrong_title = (String) params[0];
                    String wrong_content = (String) params[1];
                    Log.v("제발", "변수 ㅇㅋ");

                    //연결하고 값 넣기
                    String link = "http://www.waytech.kr/toms/app/wrong_insert.php";
                    String data = URLEncoder.encode("wrong_title", "UTF-8") + "=" + URLEncoder.encode(wrong_title, "UTF-8");
                    data += "&" + URLEncoder.encode("wrong_content", "UTF-8") + "=" + URLEncoder.encode(wrong_content, "UTF-8");
                    Log.v("제발", "값넣기 ㅇㅋ");
                    //서버연결
                    URL url = new URL(link);
                    URLConnection conn = url.openConnection();

                    conn.setDoOutput(true);
                    OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());

                    wr.write(data);
                    wr.flush();

                    BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));

                    StringBuilder sb = new StringBuilder();
                    String line = null;
                    Log.v("제발", "서버연결 ㅇㅋ");
                    // Read Server Response
                    while ((line = reader.readLine()) != null) {
                        sb.append(line);
                        break;
                    }
                    return sb.toString();
                } catch (Exception e) {
                    return new String("Exception: " + e.getMessage());
                }
            }
        }
        //최종
        InsertData task = new InsertData();
        Log.v("제발","1111 ㅇㅋ");
        task.execute(wrong_title, wrong_content);
        Log.v("제발","2222 ㅇㅋ");
    }
}
