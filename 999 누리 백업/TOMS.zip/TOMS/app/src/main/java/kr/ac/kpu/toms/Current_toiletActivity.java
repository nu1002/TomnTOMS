package kr.ac.kpu.toms;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.CheckBox;
import android.widget.TextView;

public class Current_toiletActivity extends AppCompatActivity {

    TextView toilet_use, use_rate, toilet_1, toilet_2,toilet_3, toilet_4, toilet_text, toilet_address, toilet_manager; //toilet_2_1, toilet_2_2;
    CheckBox ch_sex_y, ch_sex_n, wheel_y, wheel_n;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_current_toilet);


        //---------------------------------------------
        Intent intent = getIntent();
        String data = intent.getStringExtra("data");
        String seat = intent.getStringExtra("seat");
        String id = intent.getStringExtra("id");
//------------------------------------------------------------

        toilet_use = (TextView)findViewById(R.id.toilet_use);
        use_rate = (TextView)findViewById(R.id.use_rate);
        toilet_1 = (TextView)findViewById(R.id.toilet_1);
        toilet_2 = (TextView)findViewById(R.id.toilet_2);
        toilet_3 = (TextView)findViewById(R.id.toilet_3);
        toilet_4 = (TextView)findViewById(R.id.toilet_4);

        toilet_text = (TextView)findViewById(R.id.toilet_text);
        toilet_address = (TextView)findViewById(R.id.toilet_address);
        toilet_manager = (TextView)findViewById(R.id.toilet_manager);

        ch_sex_y = (CheckBox)findViewById(R.id.ch_sex_y);
        ch_sex_n = (CheckBox)findViewById(R.id.ch_sex_n);
        wheel_y = (CheckBox)findViewById(R.id.wheel_y);
        wheel_n = (CheckBox)findViewById(R.id.wheel_n);

        toilet_use.setText(data + ": 사용률 조회");
        use_rate.setText(seat);

        if(id.equals("m1")){
            // A동 화장실일 때 (markerid = m1)
            // 여기에 php넣어서 칸 색깔 해야할 듯
            toilet_1.setBackgroundColor(Color.parseColor("#008000"));
            toilet_1.setTextColor(Color.parseColor("#ffffff"));
            toilet_1.setText("사용중");

            toilet_2.setBackgroundColor(Color.parseColor("#008000"));
            toilet_2.setTextColor(Color.parseColor("#ffffff"));
            toilet_2.setText("사용중");

            toilet_4.setBackgroundColor(Color.parseColor("#008000"));
            toilet_4.setTextColor(Color.parseColor("#ffffff"));
            toilet_4.setText("사용중");

            toilet_text.setText("한국산업기술대학교 공학관 A동");

            ch_sex_y.setChecked(true);
            //ch_sex_n.setChecked(true);
            wheel_y.setChecked(true);
            //wheel_n.setChecked(true);
        }








        else if(id.equals("m2")){
            toilet_1.setBackgroundColor(Color.parseColor("#008000"));
            toilet_1.setTextColor(Color.parseColor("#ffffff"));
            toilet_1.setText("사용중");

            toilet_2.setBackgroundColor(Color.parseColor("#008000"));
            toilet_2.setTextColor(Color.parseColor("#ffffff"));
            toilet_2.setText("사용중");
            toilet_text.setText("한국산업기술대학교 공학관 B동");

            ch_sex_y.setChecked(true);
            wheel_y.setChecked(true);
        }
        else if(id.equals("m3")){
            toilet_1.setBackgroundColor(Color.parseColor("#008000"));
            toilet_1.setTextColor(Color.parseColor("#ffffff"));
            toilet_1.setText("사용중");


            toilet_text.setText("한국산업기술대학교 공학관 C동");

            ch_sex_y.setChecked(true);
            wheel_y.setChecked(true);
        }
        else if (id.equals("m4")){
            ch_sex_y.setChecked(true);
            wheel_y.setChecked(true);
        }




        //toilet_1_1.setBackgroundColor(Color.MAGENTA);

        //toilet_2_1.setBackgroundColor(Color.RED);
        //toilet_2_1.setText("위험");
        //Color.parseColor text.setTextColor(Color.parseColor("#FFFFFF"));
    }
}
