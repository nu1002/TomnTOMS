package kr.ac.kpu.toms;

import android.content.Intent;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.CheckBox;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Objects;

public class Current_toiletActivity extends AppCompatActivity implements SwipeRefreshLayout.OnRefreshListener {
    //static int count=0;

    //화장실 상태 Textview와 Checkbox
    TextView toilet_use, toilet_1, toilet_2, toilet_3, toilet_4, toilet_text, toilet_address, toilet_manager; //toilet_2_1, toilet_2_2;
    CheckBox ch_sex_y, ch_sex_n, wheel_y, wheel_n;
    String marker_id;

    //DB접근
    String url_1 = "http://www.waytech.kr/toms/app/seat_state_1.php";
    String url_2 = "http://www.waytech.kr/toms/app/seat_state_2.php";
    String url_3 = "http://www.waytech.kr/toms/app/seat_state_3.php";
    String url_4 = "http://www.waytech.kr/toms/app/seat_state_4.php";

    phpDown1 task_1; phpDown2 task_2; phpDown3 task_3; phpDown4 task_4;

    //새로고침
    SwipeRefreshLayout mSwipeRefreshLayout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_current_toilet);
//인텐트로 받아오는 값들
        Intent intent = getIntent();
        String data = intent.getStringExtra("data");
        String seat = intent.getStringExtra("seat");
        String id = intent.getStringExtra("id");

        marker_id = id;
        Log.v("제발","id = "+marker_id);

//------------------------------------------------------------
        toilet_use = (TextView) findViewById(R.id.toilet_use);
       // use_rate = (TextView) findViewById(R.id.use_rate);
        toilet_1 = (TextView) findViewById(R.id.toilet_1);
        toilet_2 = (TextView) findViewById(R.id.toilet_2);
        toilet_3 = (TextView) findViewById(R.id.toilet_3);
        toilet_4 = (TextView) findViewById(R.id.toilet_4);

        toilet_text = (TextView) findViewById(R.id.toilet_text);
        toilet_address = (TextView) findViewById(R.id.toilet_address);
        toilet_manager = (TextView) findViewById(R.id.toilet_manager);

        ch_sex_y = (CheckBox) findViewById(R.id.ch_sex_y);
        ch_sex_n = (CheckBox) findViewById(R.id.ch_sex_n);
        wheel_y = (CheckBox) findViewById(R.id.wheel_y);
        wheel_n = (CheckBox) findViewById(R.id.wheel_n);

        toilet_use.setText(data + ": 사용률 조회");
        //use_rate.setText(seat);

//새로고침--------------------------------------------------------------------------------
        mSwipeRefreshLayout = (SwipeRefreshLayout)findViewById(R.id.swipeRefresh);
        mSwipeRefreshLayout.setOnRefreshListener(this);

//마커별 인텐트 값---------------------------C동에만 DB접근 설정
        if(id.equals("m0")){
            finish();
        }
        else if (id.equals("m1")) {
            // A동 화장실일 때 (markerid = m1)
            toilet_1.setBackgroundColor(Color.parseColor("#008000"));
            toilet_1.setTextColor(Color.parseColor("#ffffff"));
            toilet_1.setText("사용중");

            toilet_2.setBackgroundColor(Color.parseColor("#008000"));
            toilet_2.setTextColor(Color.parseColor("#ffffff"));
            toilet_2.setText("사용중");

            toilet_4.setBackgroundColor(Color.parseColor("#008000"));
            toilet_4.setTextColor(Color.parseColor("#ffffff"));
            toilet_4.setText("사용중");

            toilet_text.setText("한국산업기술대학교 공학관 A동");

            ch_sex_y.setChecked(true);
            //ch_sex_n.setChecked(true);
            wheel_y.setChecked(true);
            //wheel_n.setChecked(true);
        } else if (id.equals("m2")) {
            toilet_1.setBackgroundColor(Color.parseColor("#008000"));
            toilet_1.setTextColor(Color.parseColor("#ffffff"));
            toilet_1.setText("사용중");

            toilet_2.setBackgroundColor(Color.parseColor("#008000"));
            toilet_2.setTextColor(Color.parseColor("#ffffff"));
            toilet_2.setText("사용중");
            toilet_text.setText("한국산업기술대학교 공학관 B동");

            ch_sex_y.setChecked(true);
            wheel_y.setChecked(true);
        }
//DB 접근 설정해둔 ***C동*******-----------------------------------------------------
        else if (id.equals("m3")) {
            toilet_text.setText("한국산업기술대학교 공학관 C동");
            ch_sex_y.setChecked(true);
            wheel_y.setChecked(true);

            task_1 = new phpDown1();
            task_1.execute(url_1);

            task_2 = new phpDown2();
            task_2.execute(url_2);

            task_3 = new phpDown3();
            task_3.execute(url_3);

            task_4 = new phpDown4();
            task_4.execute(url_4);

        } else if (id.equals("m4")) {
            toilet_text.setText("한국산업기술대학교 공학관 D동");
            ch_sex_y.setChecked(true);
            wheel_y.setChecked(true);
        }
        //Toast.makeText(getApplicationContext(),count,Toast.LENGTH_LONG).show();

    }

    @Override
    public void onRefresh() {
        Intent intent = getIntent();
        finish();
        startActivity(intent);
        mSwipeRefreshLayout.setRefreshing(false);
    }


    private class phpDown1 extends AsyncTask<String, Integer, String> {
        @Override
        protected String doInBackground(String... urls) {
            StringBuilder jsonHtml = new StringBuilder();
            try {
                // 연결 url 설정
                URL url = new URL(urls[0]);
                // 커넥션 객체 생성
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                // 연결되었으면.
                if (conn != null) {
                    conn.setConnectTimeout(10000);
                    conn.setUseCaches(false);
                    // 연결되었음 코드가 리턴되면.
                    if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                        for (; ; ) {
                            // 웹상에 보여지는 텍스트를 라인단위로 읽어 저장.
                            String line = br.readLine();
                            if (line == null) break;
                            // 저장된 텍스트 라인을 jsonHtml에 붙여넣음
                            jsonHtml.append(line + "\n");
                        }
                        br.close();
                    }
                    conn.disconnect();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return jsonHtml.toString();
        }
        protected void onPostExecute(String str) {
            //String txt1 = new String();
            try {
                JSONObject root = new JSONObject(str);
                //root라는 JSONObject 생성 ->str 값
                //String data = root.toString();
                String data = root.getString("state");

                //화장실 상태 값 : data  0(비었음) 1(사용중) 2(경고) 3(위험)
               /* if(Objects.equals("0", data)){
                    toilet_1.setText("비었음");
                    toilet_1.setBackgroundColor(Color.parseColor("#008000"));
                    toilet_1.setTextColor(Color.parseColor("#ffffff"));
                    toilet_1.setText("사용중");
                } else*/

               if((Objects.equals("1", data))||(Objects.equals("2", data))||(Objects.equals("3", data))){
                    toilet_1.setBackgroundColor(Color.parseColor("#008000"));
                    toilet_1.setTextColor(Color.parseColor("#ffffff"));
                    toilet_1.setText("사용중");
                    //count++;
               }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
    private class phpDown2 extends AsyncTask<String, Integer, String> {
        @Override
        protected String doInBackground(String... urls) {
            StringBuilder jsonHtml = new StringBuilder();
            try {
                // 연결 url 설정
                URL url = new URL(urls[0]);
                // 커넥션 객체 생성
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                // 연결되었으면.
                if (conn != null) {
                    conn.setConnectTimeout(10000);
                    conn.setUseCaches(false);
                    // 연결되었음 코드가 리턴되면.
                    if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                        for (; ; ) {
                            // 웹상에 보여지는 텍스트를 라인단위로 읽어 저장.
                            String line = br.readLine();
                            if (line == null) break;
                            // 저장된 텍스트 라인을 jsonHtml에 붙여넣음
                            jsonHtml.append(line + "\n");
                        }
                        br.close();
                    }
                    conn.disconnect();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return jsonHtml.toString();

        }
        protected void onPostExecute(String str) {
            //String txt1 = new String();
            try {
                JSONObject root = new JSONObject(str);
                //root라는 JSONObject 생성 ->str 값
                //String data = root.toString();
                String data = root.getString("state");

                if((Objects.equals("1", data))||(Objects.equals("2", data))||(Objects.equals("3", data))){
                    toilet_2.setBackgroundColor(Color.parseColor("#008000"));
                    toilet_2.setTextColor(Color.parseColor("#ffffff"));
                    toilet_2.setText("사용중");
                   // count++;
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }


    private class phpDown3 extends AsyncTask<String, Integer, String> {
        @Override
        protected String doInBackground(String... urls) {
            StringBuilder jsonHtml = new StringBuilder();
            try {
                // 연결 url 설정
                URL url = new URL(urls[0]);
                // 커넥션 객체 생성
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                // 연결되었으면.
                if (conn != null) {
                    conn.setConnectTimeout(10000);
                    conn.setUseCaches(false);
                    // 연결되었음 코드가 리턴되면.
                    if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                        for (; ; ) {
                            // 웹상에 보여지는 텍스트를 라인단위로 읽어 저장.
                            String line = br.readLine();
                            if (line == null) break;
                            // 저장된 텍스트 라인을 jsonHtml에 붙여넣음
                            jsonHtml.append(line + "\n");
                        }
                        br.close();
                    }
                    conn.disconnect();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return jsonHtml.toString();
        }
        protected void onPostExecute(String str) {
            //String txt1 = new String();
            try {
                JSONObject root = new JSONObject(str);
                //root라는 JSONObject 생성 ->str 값
                //String data = root.toString();
                String data = root.getString("state");

                if((Objects.equals("1", data))||(Objects.equals("2", data))||(Objects.equals("3", data))){
                    toilet_3.setBackgroundColor(Color.parseColor("#008000"));
                    toilet_3.setTextColor(Color.parseColor("#ffffff"));
                    toilet_3.setText("사용중");
                    //count++;
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }
    private class phpDown4 extends AsyncTask<String, Integer, String> {
        @Override
        protected String doInBackground(String... urls) {
            StringBuilder jsonHtml = new StringBuilder();
            try {
                // 연결 url 설정
                URL url = new URL(urls[0]);
                // 커넥션 객체 생성
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                // 연결되었으면.
                if (conn != null) {
                    conn.setConnectTimeout(10000);
                    conn.setUseCaches(false);
                    // 연결되었음 코드가 리턴되면.
                    if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
                        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                        for (; ; ) {
                            // 웹상에 보여지는 텍스트를 라인단위로 읽어 저장.
                            String line = br.readLine();
                            if (line == null) break;
                            // 저장된 텍스트 라인을 jsonHtml에 붙여넣음
                            jsonHtml.append(line + "\n");
                        }
                        br.close();
                    }
                    conn.disconnect();
                }
            } catch (Exception ex) {
                ex.printStackTrace();
            }
            return jsonHtml.toString();
        }
        protected void onPostExecute(String str) {
            //String txt1 = new String();
            try {
                JSONObject root = new JSONObject(str);
                //root라는 JSONObject 생성 ->str 값
                //String data = root.toString();
                String data = root.getString("state");

                if((Objects.equals("1", data))||(Objects.equals("2", data))||(Objects.equals("3", data))){
                    toilet_4.setBackgroundColor(Color.parseColor("#008000"));
                    toilet_4.setTextColor(Color.parseColor("#ffffff"));
                    toilet_4.setText("사용중");
                    //count++;
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }

        }
    }


}