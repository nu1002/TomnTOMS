package kr.ac.kpu.toms;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.HashMap;

public class menu_write extends AppCompatActivity {
    Button write_button, wrong_button;
    ListView my_review, my_wrong;
    TextView getID;

    public static Activity AActivity;
//DB 연결 -------------------------------------------------
    String myJSON;

    private static final String TAG_RESULTS = "result";
    private static final String TAG_ID = "id";
    private static final String TAG_NAME = "name";
    private static final String TAG_ADD = "address";

    JSONArray peoples = null;

    ArrayList<HashMap<String, String>> review_List;
    ArrayList<HashMap<String, String>> wrong_List;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_write);

        write_button = (Button)findViewById(R.id.write_button);
        wrong_button = (Button)findViewById(R.id.wrong_button);
        getID = (TextView)findViewById(R.id.getID);

        getID.setText("----글 작성하기----");
        /*

//DB 연결------------------------------------------------
        my_review = (ListView) findViewById(R.id.my_reviewListView);
        my_wrong = (ListView) findViewById(R.id.my_wrongListView);

        review_List = new ArrayList<HashMap<String, String>>();
        wrong_List = new ArrayList<HashMap<String, String>>();

        getData1("http://www.waytech.kr/toms/app/my_review_list.php");
        getData2("http://www.waytech.kr/toms/app/my_wrong_list.php");

*/
        //reviewAdapter.addItem(ContextCompat.getDrawable(this, R.drawable.profile_blank), "아직 글이","없습니다!");
        //wrongAdapter.addItem(ContextCompat.getDrawable(this, R.drawable.profile_blank), "아직 글이","없습니다!");

      // for(int i=0; i<3; i++){
       //     reviewAdapter.addItem(ContextCompat.getDrawable(this, R.drawable.profile_blank), "리뷰타이틀"+i, "리뷰본문"+i);
      //  }
      //  for(int i=0; i<3; i++){
      //      wrongAdapter.addItem(ContextCompat.getDrawable(this, R.drawable.profile_blank), "고장타이틀"+i, "고장본문"+i);
      //  }


     //  mypage.setText(ID);
       write_button.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               Intent intent = new Intent(menu_write.this, menu_wrong.class);
               startActivity(intent);
           }
       });
       wrong_button.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               Intent intent = new Intent(menu_write.this, menu_review.class);
               startActivity(intent);
           }
       });
    }

}
