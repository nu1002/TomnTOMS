package kr.ac.kpu.toms;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.HashMap;

public class menu_write extends AppCompatActivity {
    Button write_button, wrong_button;
    ListView my_review, my_wrong;
    TextView getID;
    //TextView mypage;

//DB 연결 -------------------------------------------------
    String myJSON;

    private static final String TAG_RESULTS = "result";
    private static final String TAG_ID = "id";
    private static final String TAG_NAME = "name";
    private static final String TAG_ADD = "address";

    JSONArray peoples = null;

    ArrayList<HashMap<String, String>> review_List;
    ArrayList<HashMap<String, String>> wrong_List;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_write);

        write_button = (Button)findViewById(R.id.write_button);
        wrong_button = (Button)findViewById(R.id.wrong_button);
        getID = (TextView)findViewById(R.id.getID);

        //reviewAdapter = new ListViewAdapter();
        //wrongAdapter = new ListViewAdapter();

        //reviewList =(ListView)findViewById(R.id.reviewListView);
        //reviewList.setAdapter(reviewAdapter);

        //wrongList = (ListView)findViewById(R.id.wrongListView);
        //wrongList.setAdapter(wrongAdapter);


        getID.setText("user77");
        /*

//DB 연결------------------------------------------------
        my_review = (ListView) findViewById(R.id.my_reviewListView);
        my_wrong = (ListView) findViewById(R.id.my_wrongListView);

        review_List = new ArrayList<HashMap<String, String>>();
        wrong_List = new ArrayList<HashMap<String, String>>();

        getData1("http://www.waytech.kr/toms/app/my_review_list.php");
        getData2("http://www.waytech.kr/toms/app/my_wrong_list.php");

*/
        //reviewAdapter.addItem(ContextCompat.getDrawable(this, R.drawable.profile_blank), "아직 글이","없습니다!");
        //wrongAdapter.addItem(ContextCompat.getDrawable(this, R.drawable.profile_blank), "아직 글이","없습니다!");

      // for(int i=0; i<3; i++){
       //     reviewAdapter.addItem(ContextCompat.getDrawable(this, R.drawable.profile_blank), "리뷰타이틀"+i, "리뷰본문"+i);
      //  }
      //  for(int i=0; i<3; i++){
      //      wrongAdapter.addItem(ContextCompat.getDrawable(this, R.drawable.profile_blank), "고장타이틀"+i, "고장본문"+i);
      //  }


     //  mypage.setText(ID);
       write_button.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               Intent intent = new Intent(menu_write.this, menu_wrong.class);
               startActivity(intent);
           }
       });
       wrong_button.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               Intent intent = new Intent(menu_write.this, menu_review.class);
               startActivity(intent);
           }
       });
    }
    /*
    protected void showList1() {
        try {
            JSONObject jsonObj = new JSONObject(myJSON);
            peoples = jsonObj.getJSONArray(TAG_RESULTS);

            for (int i = 0; i < peoples.length(); i++) {
                JSONObject c = peoples.getJSONObject(i);
                String id = c.getString(TAG_ID);
                String name = c.getString(TAG_NAME);
                String address = c.getString(TAG_ADD);

                HashMap<String, String> persons = new HashMap<String, String>();

                persons.put(TAG_ID, id);
                persons.put(TAG_NAME, name);
                persons.put(TAG_ADD, address);

                review_List.add(persons);
            }

            ListAdapter adapter = new SimpleAdapter(
                    menu_write.this, review_List, R.layout.list_item,
                    new String[]{TAG_ID, TAG_NAME, TAG_ADD}, new int[]{R.id.id, R.id.name, R.id.address}
            );
            my_review.setAdapter(adapter);
            //my_wrong.setAdapter(adapter);하면 같은거
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void getData1(String url) {
        class GetDataJSON extends AsyncTask<String, Void, String> {

            @Override
            protected String doInBackground(String... params) {
                String uri = params[0];
                BufferedReader bufferedReader = null;

                try {
                    URL url = new URL(uri);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    StringBuilder sb = new StringBuilder();

                    bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));

                    String json;
                    while ((json = bufferedReader.readLine()) != null) {
                        sb.append(json + "\n");
                    }
                    return sb.toString().trim();
                } catch (java.io.IOException e) {
                    return null;
                }
            }

            @Override
            protected void onPostExecute(String result) {
                myJSON = result;
                showList1();
            }
        }
        GetDataJSON g = new GetDataJSON();
        g.execute(url);
    }
    protected void showList2() {
        try {
            JSONObject jsonObj = new JSONObject(myJSON);
            peoples = jsonObj.getJSONArray(TAG_RESULTS);

            for (int i = 0; i < peoples.length(); i++) {
                JSONObject c = peoples.getJSONObject(i);
                String id = c.getString(TAG_ID);
                String name = c.getString(TAG_NAME);
                String address = c.getString(TAG_ADD);

                HashMap<String, String> persons = new HashMap<String, String>();

                persons.put(TAG_ID, id);
                persons.put(TAG_NAME, name);
                persons.put(TAG_ADD, address);

                wrong_List.add(persons);
            }

            ListAdapter adapter = new SimpleAdapter(
                    menu_write.this, wrong_List, R.layout.list_item,
                    new String[]{TAG_ID, TAG_NAME, TAG_ADD}, new int[]{R.id.id, R.id.name, R.id.address}
            );
            my_review.setAdapter(adapter);
            //my_wrong.setAdapter(adapter);하면 같은거
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    public void getData2(String url) {
        class GetDataJSON extends AsyncTask<String, Void, String> {

            @Override
            protected String doInBackground(String... params) {
                String uri = params[0];
                BufferedReader bufferedReader = null;

                try {
                    URL url = new URL(uri);
                    HttpURLConnection con = (HttpURLConnection) url.openConnection();
                    StringBuilder sb = new StringBuilder();

                    bufferedReader = new BufferedReader(new InputStreamReader(con.getInputStream()));

                    String json;
                    while ((json = bufferedReader.readLine()) != null) {
                        sb.append(json + "\n");
                    }
                    return sb.toString().trim();
                } catch (java.io.IOException e) {
                    return null;
                }
            }

            @Override
            protected void onPostExecute(String result) {
                myJSON = result;
                showList2();
            }
        }
        GetDataJSON g = new GetDataJSON();
        g.execute(url);
    }
    */
}
