<?php
header("Content-Type: text/html; charset=UTF-8");	//charset 설정
$mysql_hostname = "waytech.kr";
$mysql_username = "waytechtest";
$mysql_password = "dnpdl123";
$mySql_database = "waytechtest";

$connect = mysqli_connect($mysql_hostname, $mysql_username, $mysql_password, $mySql_database);	//DB연결

if(mysqli_connect_errno($connect)){
	echo "DB fail";
}
else{
	echo "DB success";
}
echo'<br>';

$usingTime = $_GET["usingTime"];
$seatState = $_GET["seatState"];
$tissueState = $_GET["tissueState"];


$query = "INSERT INTO bigToilet (usingTime, seatState, tissueState, time) VALUES ('$usingTime', '$seatState', '$tissueState', NOW())";
$result = mysqli_query($connect, $query) or die ('Error inserting DB');		//연결된 DB에 쿼리 실행

mysqli_close($connect);			//DB 연결 종료

?>