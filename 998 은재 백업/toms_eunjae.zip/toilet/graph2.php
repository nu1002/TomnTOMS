<?
  session_start();

  if(!$_SESSION[manager_id]){
    ?>
    <script>
      alert("로그인 하세요.");
      location.replace("../login/login.php");
    </script>
    <?
      } 
    ?>
<? 
        include "../db_1.php";
        $sql="SELECT *from toilet where toilet_UID =3" ;
        $result=mysqli_query($connect, $sql);
        $row = mysqli_fetch_array($result) or die('x');
?>

<!DOCTYPE html>
<html>
<head>
  <title> 화장실 전체 사용률 </title>

  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="../css/main.css" media="all">

</head>
 <body onload="initialize()">
  <header>
      <? include "../lib/top_login2.php"; ?>
      <hr style="border: solid 0.5px #AAABD3;">
      <? include "../lib/top_menu2.php"; ?>
      <hr style="border: solid 0.5px #AAABD3;">
  </header>
    <section id="tom">
      <nav>
      <? include "../lib/left_menu2.php"; ?>
     </nav>
      <center>
    <article>
    <div id="title"> <!--타이틀 나중에 이미지로 넣기-->
      <h2>시간별 화장실 사용률</h2>
    </div>  <!-- end of title -->
    <?
        include "graphdata2.php";

      ?>
    </article>
  </center>
  </section>

  <footer>Made by TOM( Park Nuri, Park JunMin, Bae Eunjae)</footer>
</body>
</html>