<?
  session_start();

  if(!$_SESSION[manager_id]){
    ?>
    <script>
      alert("로그인 하세요.");
      location.replace("../login/login.php");
    </script>
    <?
  } 
?>
<? 
        include "../db_1.php";
        $sql="SELECT *from toilet where toilet_UID =3" ;
        $result=mysqli_query($connect, $sql);
        $row = mysqli_fetch_array($result) or die('x');
?>

<!DOCTYPE html>
<html>
<head>
  <title>나의 화장실 </title>
  <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false&language=ko"></script>
  
  <script>
    function initialize() {
      var myLatlng = new google.maps.LatLng(37.339966, 126.733915);
      var mapOptions = {
        zoom: 15,
        center: myLatlng,
        mapTypeId: google.maps.MapTypeId.ROADMAP
      }

      var map = new google.maps.Map(document.getElementById('map_canvas'), mapOptions);
      var marker = new google.maps.Marker({
        position: myLatlng,
        map: map,
        title: "회사이름"
      });

      var infowindow = new google.maps.infoWindow(
      {
        content: "<h1>회사이름</h1>",
        maxWidth:300
      });

    }
  </script>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="../css/main.css" media="all">

</head>
 <body onload="initialize()">
  <header>
      <? include "../lib/top_login2.php"; ?>
      <hr style="border: solid 0.5px #AAABD3;">
      <? include "../lib/top_menu2.php"; ?>
      <hr style="border: solid 0.5px #AAABD3;">
  </header>
    <section id="tom">
      <nav>
      <? include "../lib/left_menu2.php"; ?>
     </nav>
      <center>
    <article>
    <div id="title"> <!--타이틀 나중에 이미지로 넣기-->
      <h2>나의 화장실</h2>
    </div>  <!-- end of title -->
    <div id="map_canvas" style="width: 400px; height: 300px;"></div>
    <br>

    <?
        echo " <table text-align=center> <tr> <td > 화장실 이름 </td> <td> $row[toilet_name] </td> <br/>"; 
        echo "<tr> <td> 화장실 주소 </td> <td> $row[toilet_address] </td> <br/>";
        echo "<tr> <td> 남녀공용 여부 </td> <td> $row[toilet_unisex] </td> <br/>";
        echo "<tr> <td> 화장실 연락처 </td> <td> $row[toilet_phone] </td> </table>";

    ?>
    </article>
  </center>
  </section>

  <footer>Made by TOM( Park Nuri, Park JunMin, Bae Eunjae)</footer>
</body>
</html>