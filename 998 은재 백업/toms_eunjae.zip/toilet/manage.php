<?
  session_start();
?>

<!DOCTYPE html>
<html>
<head>
  <title>화장실 시설 점검표</title>
  <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false&language=ko"></script>
 
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="../css/main.css" media="all">
  <link rel="stylesheet" type="text/css" href="../css/list.css" media="all">
</head>
<? 
      include "../db_1.php";
      $UID = $_GET["fac_UID"];
      $sql="SELECT *from check_fac where fac_UID=$UID" ;
      $result=mysqli_query($connect, $sql);
      $row = mysqli_fetch_array($result) or die('x');
      if($row[0]) {
    $number = $row[0]+1;
  }else{
    $number = 1;
  }
      $content = nl2br($row[content]);
?>

 <body onload="initialize()">
  <header>
      <? include "../lib/top_login2.php"; ?>
      <hr style="border: solid 0.5px #AAABD3;">
      <? include "../lib/top_menu2.php"; ?>
      <hr style="border: solid 0.5px #AAABD3;">
  </header>
    <section id="tom">
      <nav>
      <? include "../lib/left_menu3.php"; ?>
     </nav>
      <center>
    <article>
    <div id="title"> <!--타이틀 나중에 이미지로 넣기-->
      <h2>
        <? 
        $manager_name = $_SESSION['manager_name'];
        echo "$manager_name"; 
        ?>
      </h2>
    </div>  <!-- end of title -->
    <table class="list" cellpadding=2 cellspacing=1>
      <thead>
        <tr class="head">
          <td colspan="3">
            <B> [ 화장실 시설 점검표 ] </B></font>
          </td>
          </tr>
          <tr class="head"> 
              <th col width="10%">항목</th>
              <th col width="*" >점검항목</th>
              <th col width="15%" >점검자</th>
          </tr>

            <tr bgcolor=white>
              <td col width="10%" rowspan="6">변기 및 주변</td>
              <td col width="*" >파손되어 있지 않은가</td>
              <td col width="15%"><? echo "$row[fac1_1]" ?></td>
            </tr>
            <tr bgcolor=white>
              <td col width="*" >세정수량은 적당한가(급수)</td>
              <td col width="15%"><? echo "$row[fac1_2]" ?></td>
            </tr>
            <tr bgcolor=white>
              <td col width="*" >물이 잘 배수 되는가(배수)</td>
              <td col width="15%"><? echo "$row[fac1_3]" ?></td>
            </tr>
            <tr bgcolor=white>
              <td col width="*" >후레시 밸스, 정상작동 및 누수는 없는가</td>
              <td col width="15%"><? echo "$row[fac1_4]" ?></td>
            </tr>
            <tr bgcolor=white>
              <td col width="*" >오염물질, 요석 등이 붙어있지 않은가</td>
              <td col width="15%"><? echo "$row[fac1_5]" ?></td>
            </tr>
            <tr bgcolor=white>
              <td col width="*" >금구류에 부식(녹)이 발생하지 않은가</td>
              <td col width="15%"><? echo "$row[fac1_6]" ?></td>
            </tr>

            <tr bgcolor=white>
              <td col width="10%" rowspan="6">세면기 및 주변</td>
              <td col width="*" >수도꼭지, 파손 및 누수가 없는가</td>
              <td col width="15%"><? echo "$row[fac2_1]" ?></td>
            </tr>
            <tr bgcolor=white>
              <td col width="*" >세면기의 파손이 없는가</td>
              <td col width="15%"><? echo "$row[fac2_2]" ?></td>
            </tr>
            <tr bgcolor=white>
              <td col width="*" >세면기의 물이 잘 배수 되는가</td>
              <td col width="15%"><? echo "$row[fac2_3]" ?></td>
            </tr>
            <tr bgcolor=white>
              <td col width="*" >트랩(배수관)에 고장이 없는가</td>
              <td col width="15%"><? echo "$row[fac2_4]" ?></td>
            </tr>
            <tr bgcolor=white>
              <td col width="*" >거울이 파손, 오염 되어 있지 않은가</td>
              <td col width="15%"><? echo "$row[fac2_5]" ?></td>
            </tr>
            <tr bgcolor=white>
              <td col width="*" >금구류에 부식(녹)이 발생하지 않은가</td>
              <td col width="15%"><? echo "$row[fac2_6]" ?></td>
            </tr>

            <tr bgcolor=white>
              <td col width="10%" rowspan="4">바닥면</td>
              <td col width="*" >배수구의 물이 잘 빠지는가</td>
              <td col width="15%"><? echo "$row[fac3_1]" ?></td>
            </tr>
            <tr bgcolor=white>
              <td col width="*" >배수구의 봉수가 들어 있는가</td>
              <td col width="15%"><? echo "$row[fac3_2]" ?></td>
            </tr>
            <tr bgcolor=white>
              <td col width="*" >타일 등이 파손되어 있지 않은가</td>
              <td col width="15%"><? echo "$row[fac3_3]" ?></td>
            </tr>
            <tr bgcolor=white>
              <td col width="*" >오염된 때가 부착되어 있지 않은가</td>
              <td col width="15%"><? echo "$row[fac3_4]" ?></td>
            </tr>
            
            <tr bgcolor=white>
              <td col width="10%" rowspan="4">화장실면</td>
              <td col width="*" >문이 파손되어 있지 않은가</td>
              <td col width="15%"><? echo "$row[fac4_1]" ?></td>
            </tr>
            <tr bgcolor=white>
              <td col width="*" >도어 경첩이 파손되어 있지 않은가</td>
              <td col width="15%"><? echo "$row[fac4_2]" ?></td>
            </tr>
            <tr bgcolor=white>
              <td col width="*" >잠금장치가 파손되어 있지 않은가</td>
              <td col width="15%"><? echo "$row[fac4_3]" ?></td>
            </tr>
            <tr bgcolor=white>
              <td col width="*" >칸막이 문짝에 불법광고물, 낙서, 오염물질이 부착되어있지 않은가</td>
              <td col width="15%"><? echo "$row[fac4_4]" ?></td>
            </tr>
            
            <tr bgcolor=white>
              <td col width="10%">기타</td>
              <td col width="*"  colspan="2"><? echo "$row[fac_etc]" ?></td>
            </tr>

            <tr bgcolor=white>
              <td col width="10%" colspan="3">양호, 보통, 불량</td>
            </tr>

          </thead>
          <tbody>
          <tr>
            
      </table>
  </article>
  </center>
  </section>

  <footer>Made by TOM( Park Nuri, Park JunMin, Bae Eunjae)</footer>
</body>
</html>
