<?
  session_start();
?>

<!DOCTYPE html>
<html>
<head>
  <title>화장실 청결 점검표</title>
  <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false&language=ko"></script>
 
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="../css/main.css" media="all">
  <link rel="stylesheet" type="text/css" href="../css/list.css" media="all">
</head>
<? 
      include "../db_1.php";
      $UID = $_GET["gar_UID"];
      $sql="SELECT *from check_gar where gar_UID=$UID" ;
      $result=mysqli_query($connect, $sql);
      $row = mysqli_fetch_array($result) or die('x');
      if($row[0]) {
      $number = $row[0]+1;
      }else{
      $number = 1;
      }
      $content = nl2br($row[content]);
?>

 <body onload="initialize()">
  <header>
      <? include "../lib/top_login2.php"; ?>
      <hr style="border: solid 0.5px #AAABD3;">
      <? include "../lib/top_menu2.php"; ?>
      <hr style="border: solid 0.5px #AAABD3;">
  </header>
    <section id="tom">
      <nav>
      <? include "../lib/left_menu3.php"; ?>
     </nav>
      <center>
    <article>
    <div id="title"> <!--타이틀 나중에 이미지로 넣기-->
      <h2>
        <? 
        $manager_name = $_SESSION['manager_name'];
        echo "$manager_name"; 
        ?>
      </h2>
    </div>  <!-- end of title -->
    <table class="list" cellpadding=2 cellspacing=1>
      <thead>
        <tr class="head">
          <td colspan="3">
            <B> [ 화장실 비품 대장 ] </B></font>
          </td>
          </tr>
          <tr class="head"> 
              <th col width="10%">번호</th>
              <th col width="*" >비품</th>
              <th col width="15%" >수량</th>
          </tr>

            <tr bgcolor=white>
              <td col width="10%">1</td>
              <td col width="*" > 
              <? echo "$row[gar1n]</td> " ?>
              <td col width="15%">
              <? echo "$row[gar1c] </td>" ?>
              
            </tr>

            <tr bgcolor=white>
              <td col width="10%">2</td>
              <td col width="*" > 
              <? echo "$row[gar2n]</td> " ?>
              <td col width="15%">
              <? echo "$row[gar2c] </td>" ?>
            </tr>

            <tr bgcolor=white>
              <td col width="10%">3</td>
              <td col width="*" > 
              <? echo "$row[gar3n]</td> " ?>
              <td col width="15%">
              <? echo "$row[gar3c] </td>" ?>
            </tr>

            <tr bgcolor=white>
              <td col width="10%">4</td>
              <td col width="*" > 
              <? echo "$row[gar4n]</td> " ?>
              <td col width="15%">
              <? echo "$row[gar4c] </td>" ?>
            </tr>

            <tr bgcolor=white>
              <td col width="10%">5</td>
              <td col width="*" > 
              <? echo "$row[gar5n]</td> " ?>
              <td col width="15%">
              <? echo "$row[gar5c] </td>" ?>
            </tr>

            <tr bgcolor=white>
              <td col width="10%">6</td>
              <td col width="*" > 
              <? echo "$row[gar6n]</td> " ?>
              <td col width="15%">
              <? echo "$row[gar6c] </td>" ?>
            </tr>

            <tr bgcolor=white>
              <td col width="10%">7</td>
              <td col width="*" > 
              <? echo "$row[gar7n]</td> " ?>
              <td col width="15%">
              <? echo "$row[gar7c] </td>" ?>
            </tr>

            <tr bgcolor=white>
              <td col width="10%">8</td>
              <td col width="*" > 
              <? echo "$row[gar8n]</td> " ?>
              <td col width="15%">
              <? echo "$row[gar8c] </td>" ?>
            </tr>

            <tr bgcolor=white>
              <td col width="10%">9</td>
              <td col width="*" > 
              <? echo "$row[gar9n]</td> " ?>
              <td col width="15%">
              <? echo "$row[gar9c] </td>" ?>
            </tr>

            <tr bgcolor=white>
              <td col width="10%">10</td>
              <td col width="*" > 
              <? echo "$row[gar10n]</td> " ?>
              <td col width="15%">
              <? echo "$row[gar10c] </td>" ?>
            </tr>
          </thead>
          <tbody>
          <tr>
            
      </table>
      <a href=item_list.php>
      <input type="button" value=" 뒤로가기">
  </article>
  </center>
  </section>

  <footer>Made by TOM( Park Nuri, Park JunMin, Bae Eunjae)</footer>
</body>
</html>
