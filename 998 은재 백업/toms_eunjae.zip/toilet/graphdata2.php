<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>화장실 전체 사용률</title>
       <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['line']});
      google.charts.setOnLoadCallback(drawChart);

    function drawChart() {

      var data = new google.visualization.DataTable();
      data.addColumn('number', '');
      data.addColumn('number', '남성(명)');
      data.addColumn('number', '여성(명)');
      data.addColumn('number', '전체(명)');
      
      data.addRows([
        [0,  02, 03, 05],
        [2,  00, 00, 00],
        [4,  01, 02, 03],
        [6, 11, 18, 29],
        [8, 10, 27, 37],
        [10, 18, 23, 41],
        [12, 44, 35, 79],
        [14, 28, 19, 47],
        [16, 68, 51, 129],
        [18, 37, 41, 78],
        [20, 31, 17, 48],
        [22, 10, 09, 19],
        [24, 05, 03, 08]
      ]);

      var options = {
        width: 800,
        height: 400,
        fontSize: 15
      };

      var chart = new google.charts.Line(document.getElementById('linechart_material'));

      chart.draw(data, google.charts.Line.convertOptions(options));
    }
    </script>
  </head>
  <body>
    <div  id="linechart_material" style="width: 1000px; height: 500px" ></div>
  </body>
</html>