<?php
	require("phpsqlajax_dbinfo.php");

	function parseToMXL($htmlStr)
	{
		$xmlStr=str_replace('<', '&lt', $htmlStr);
		$xmlStr=str_replace('>', '&gt', $xmlStr);
		$xmlStr=str_replace('"', '&quot', $xmlStr);
		$xmlStr=str_replace("'", '&#39', $xmlStr);
		$xmlStr=str_replace('&', '&amp', $xmlStr);
		return $xmlStr;
	}

	$connect=mysqli_connect("localhost", "toms", "passwd");
	if (!$connect) {
		die('Not connected : '.mysql_error());
	}

	$db_selected = mysql_select_db($toms, $connect);
	if (!$db_selected) {
		die('Can\'t use db : '.mysql_error());
	}

	header("Content-type : text/xml");

	echo '<markers>';

	while ($row = @mysql_fetch_assoc($result)){
		echo '<marker';
		echo 'name';
	}

?>