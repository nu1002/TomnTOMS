<?
  session_start();

  if(!$_SESSION[manager_id]){
    ?>
    <script>
      alert("로그인 하세요.");
      location.replace("../login/login.php");
    </script>
    <?
  } 
?>

<!DOCTYPE html>
<html>
<head>

  <title>화장실 사용률</title>
  <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false&language=ko"></script>

  <meta charset="utf-8">
  <meta http-equiv="refresh" content="5">
  <link rel="stylesheet" type="text/css" href="../css/main.css" media="all">
  <link rel="stylesheet" type="text/css" href="../css/toilet.css" media="all">
</head>
 <body onload="initialize()">
  <header>
      <? include "../lib/top_login2.php"; ?>
      <hr style="border: solid 0.5px #AAABD3;">
      <? include "../lib/top_menu2.php"; ?>
      <hr style="border: solid 0.5px #AAABD3;">
  </header>
    <section id="tom">
      <nav>
      <? include "../lib/left_menu2.php"; ?>
     </nav>
      <center>
    <article>
    <div id="title"> <!--타이틀 나중에 이미지로 넣기-->
      <h2>현재 사용률</h2>
    </div>  <!-- end of title -->
    <?
     $connect=mysqli_connect("waytech.kr", "waytechtest", "dnpdl123", "waytechtest");
     $query = "SELECT * FROM arduino1 order by time desc limit 1";   //db select문  
     $result = mysqli_query($connect, $query) or die ('Error querying database'); 

     $connect1=mysqli_connect("waytech.kr", "waytechtest", "dnpdl123", "waytechtest");
     $query1 = "SELECT * FROM arduino2 order by time desc limit 1";   //db select문  
     $result1 = mysqli_query($connect1, $query1) or die ('Error querying database'); 
     

    $connect2=mysqli_connect("waytech.kr", "waytechtest", "dnpdl123", "waytechtest");
     $query2 = "SELECT * FROM bigToilet order by time desc limit 1";   //db select문  
     $result2 = mysqli_query($connect2, $query2) or die ('Error querying database'); 
     

     $row = mysqli_fetch_array($result);
     $row1 = mysqli_fetch_array($result1);
     $row2 = mysqli_fetch_array($result2);


     $s1Use = $row2[usingTime];
     $s2Use = $row[usingTime2];
      $s3Use = $row1[usingTime3];
     $s4Use = $row1[usingTime4];

     if($s1Use > "60"){  //15초 이상 사용시 
      $s1Bg = "background:#f1404b";
     }
     elseif($s1Use > "30"){ //5초 이상 사용시
      $s1Bg = "background:#FFBC42";
     }
     elseif($s1Use > "0"){ //5초 이상 사용시
      $s1Bg = "background:#a3a1a1";
     }
     else{ //그 이외의 경우
      $s1Bg = "background:#f4f5f9";
     }

    
      if($s2Use > "60"){  //15초 이상 사용시 
       $s2Bg = "background:#f1404b";
      }
      elseif($s2Use > "30"){ //5초 이상 사용시
        $s2Bg = "background:#FFBC42";
     }
     elseif($s2Use > "0"){ //5초 이상 사용시
        $s2Bg = "background:#a3a1a1";
     }
      else{ //그 이외의 경우
       $s2Bg = "background:#f4f5f9";
      }



     if($s3Use > "60"){  //15초 이상 사용시 
      $s3Bg = "background:#f1404b";
     }
     elseif($s3Use > "30"){ //5초 이상 사용시
      $s3Bg = "background:#FFBC42";
     }
     elseif($s3Use > "0"){ //5초 이상 사용시
        $s3Bg = "background:#a3a1a1";
     }
     else{ //그 이외의 경우
      $s3Bg = "background:#f4f5f9";
     }

    
      if($s4Use > "50"){ //15초 이상 사용시 
       $s4Bg = "background:#f1404b";
      }
      elseif($s4Use > "30"){ //5초 이상 사용시
        $s4Bg = "background:#FFBC42";
     }
     elseif($s4Use > "0"){ //5초 이상 사용시
        $s4Bg = "background:#a3a1a1";
     }
      else{ //그 이외의 경우
       $s4Bg = "background:#f4f5f9";
      }

    ?>
  <script type="text/javascript">
       function btn_confirm1(){
         var check = confirm("긴급상황일 수 있습니다. 확인하셨습니까?");
         if(check) {
           alert("확인해주십시오.");
 
         }

      }
      function btn_confirm2(){
         var check = confirm("긴급상황일 수 있습니다. 확인하셨습니까?");
         if(check) 
          alert("확인해주십시오.");
      }

      function btn_confirm3(){
         var check = confirm("긴급상황일 수 있습니다. 확인하셨습니까?");
         if(check) {
           alert("확인해주십시오.");
 
         }

      }
      function btn_confirm4(){
         var check = confirm("긴급상황일 수 있습니다. 확인하셨습니까?");
         if(check) 
          alert("확인해주십시오.");
      }


     </script>


  <div class="seat-frame" id="toilet">
    남자화장실<br>
   <input type="button" name="seat1" style="<? echo "$s1Bg" ?>" class="seat" id="seat" value="사용시간: <? echo $s1Use ?>초" onclick="btn_confirm1();">
   
   <input type="button" name="seat2" style="<? echo "$s2Bg" ?>" class="seat" id="seat" value="사용시간: <? echo $s2Use ?>초" onclick="btn_confirm2();">
   </div>
   <br><br>
   <div class="seat-frame"  id="toilet">
   여자화장실<br>
   <input type="button" name="seat3" style="<? echo "$s3Bg" ?>" class="seat" id="seat" value="사용시간: <? echo $s3Use ?>초" onclick="btn_confirm3();">
   <input type="button" name="seat4" style="<? echo "$s4Bg" ?>" class="seat" id="seat" value="사용시간: <? echo $s4Use ?>초" onclick="btn_confirm4();">
   </div>

  <?
  mysqli_free_result($result);
  mysqli_close($connect);
    ?>
  </center>
  </section>

  <footer>Made by TOM( Park Nuri, Park JunMin, Bae Eunjae)</footer>
</body>
</html>