<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>화장실 전체 사용률</title>
       <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">
      google.charts.load('current', {'packages':['corechart']});
      google.charts.setOnLoadCallback(drawChart);

      function drawChart() {
        var data = google.visualization.arrayToDataTable([
          ['date', 'man', 'woman'],
          ['10월 05일',  15,      40],
          ['10월 06일',  35,      46],
          ['10월 07일',  26,       112],
          ['10월 08일',  42,      54],
          ['10월 09일',  53,      68],
          ['10월 10일',  62,      152],
          ['10월 11일',  23,      51]
        ]);

        var options = {
          curveType: 'function',
          legend: { position: 'right' }
        };

        var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));

        chart.draw(data, options);
      }
    </script>
  </head>
  <body>
    <div id="curve_chart" style="width: 1000px; height: 500px"></div>
  </body>
</html>