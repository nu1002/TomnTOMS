<?
  session_start();
?>

<!DOCTYPE html>
<html>
<head>
  <title>화장실 청결 점검표</title>
  <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false&language=ko"></script>
 
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="../css/main.css" media="all">
  <link rel="stylesheet" type="text/css" href="../css/list.css" media="all">
</head>
<? 
      include "../db_1.php";
      $UID = $_GET["clean_UID"];
      $sql="SELECT *from check_clean where clean_UID=$UID" ;
      $result=mysqli_query($connect, $sql);
      $row = mysqli_fetch_array($result) or die('x');
      if($row[0]) {
    $number = $row[0]+1;
  }else{
    $number = 1;
  }
      $content = nl2br($row[content]);
?>
 <body onload="initialize()">
  <header>
      <? include "../lib/top_login2.php"; ?>
      <hr style="border: solid 0.5px #AAABD3;">
      <? include "../lib/top_menu2.php"; ?>
      <hr style="border: solid 0.5px #AAABD3;">
  </header>
    <section id="tom">
      <nav>
      <? include "../lib/left_menu3.php"; ?>
     </nav>
      <center>
    <article>
    <div id="title"> <!--타이틀 나중에 이미지로 넣기-->
      <h2>
        <? 
        $manager_name = $_SESSION['manager_name'];
        echo "$manager_name"; 
        ?>
      </h2>
    </div>  <!-- end of title -->
    <table class="list" cellpadding=2 cellspacing=1>
      <thead>
        <tr class="head">
          <td colspan="3">
            <B> [ 화장실 청결 점검표 ] </B></font>
          </td>
          </tr>
          <tr class="head"> 
              <th col width="10%">번호</th>
              <th col width="*" >점검항목</th>
              <th col width="15%" >점검상태</th>
          </tr>

            <tr bgcolor=white>
              <td col width="10%">1</td>
              <td col width="*" >화장실 바닥은 물기가 없습니까?</td>
              <td col width="15%"><? echo "$row[clean1]" ?></td>
            </tr>

            <tr bgcolor=white>
              <td col width="10%">2</td>
              <td col width="*" >세면기는 깨끗하게 닦여 있습니까?</td>
              <td col width="15%"><? echo "$row[clean2]" ?></td>
            </tr>

            <tr bgcolor=white>
              <td col width="10%">3</td>
              <td col width="*" >거울은 깨끗하게 닦여 있습니까?</td>
              <td col width="15%"><? echo "$row[clean3]" ?></td>
            </tr>

            <tr bgcolor=white>
              <td col width="10%">4</td>
              <td col width="*" >비누는 보충되어 있습니까?</td>
              <td col width="15%"><? echo "$row[clean4]" ?></td>
            </tr>

            <tr bgcolor=white>
              <td col width="10%">5</td>
              <td col width="*" >화장실용 휴지는 준비되어 있습니까?</td>
              <td col width="15%"><? echo "$row[clean5]" ?></td>
            </tr>

            <tr bgcolor=white>
              <td col width="10%">6</td>
              <td col width="*" >휴지통의 휴지는 넘치지 않았습니까?</td>
              <td col width="15%"><? echo "$row[clean6]" ?></td>
            </tr>

            <tr bgcolor=white>
              <td col width="10%">7</td>
              <td col width="*" >물을 내리지 않은 변기는 없습니까?</td>
              <td col width="15%"><? echo "$row[clean7]" ?></td>
            </tr>

            <tr bgcolor=white>
              <td col width="10%">8</td>
              <td col width="*" >냄새가 나지 않습니까?</td>
              <td col width="15%"><? echo "$row[clean8]" ?></td>
            </tr>

            <tr bgcolor=white>
              <td col width="10%">9</td>
              <td col width="*" >조명등은 고장 나 있지 않습니까?</td>
              <td col width="15%"><? echo "$row[clean9]" ?></td>
            </tr>

            <tr bgcolor=white>
              <td col width="10%">10</td>
              <td col width="*" >환기용 팬은 돌아가고 있습니까?</td>
              <td col width="15%"><? echo "$row[clean10]" ?></td>
            </tr>

            <tr bgcolor=white>
              <td col width="10%">11</td>
              <td col width="*" >기기의 고장은 없습니까?</td>
              <td col width="15%"><? echo "$row[clean11]" ?></td>
            </tr>

            <tr bgcolor=white>
              <td col width="10%">12</td>
              <td col width="*" >변기가 막힌 곳은 없습니까?</td>
              <td col width="15%"><? echo "$row[clean12]" ?></td>
            </tr>

            <tr bgcolor=white>
              <td col width="10%">기타</td>
              <td col width="*" colspan="2" ><? echo "$row[clean_etc]" ?></td>
            </tr>

            <tr bgcolor=white>
              <td col width="10%" colspan="4">양호, 보통, 불량</td>
            </tr>

          </thead>
          <tbody>
          <tr>
            
      </table>
  </article>
  </center>
  </section>

  <footer>Made by TOM( Park Nuri, Park JunMin, Bae Eunjae)</footer>
</body>
</html>
