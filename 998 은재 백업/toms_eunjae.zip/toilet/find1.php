<?php

  $username = "toms"
  $password = "passwd"
  $database = "toms"

?>

<!DOCTYPE html>
<html>
<head>
  <title>나의 화장실</title>
  <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false&language=ko"></script>
</head>
<body>

</body>
</html>

<?php
    require("dbconn.php");

    $dom = new DOMDocument("1.0");

    $node = $dom->createElement("toms");

    $parnode = $dom->appendChild($node);

    if (!$connect) {  die('Not connected : ' . mysqli_error());}

    $db_selected = mysqli_select_db($database, $connect);

    if (!$db_selected) {

     die ('Can\'t use db : ' . mysql_error());

    }


    $query = "SELECT * FROM toms";

    $result = mysqli_query($query);

if (!$result) {

  die('Invalid query: ' . mysql_error());

}

header("Content-type: text/xml");


while ($row = @mysql_fetch_assoc($result)){


  $node = $dom->createElement("soffender");

  $newnode = $parnode->appendChild($node);

  $newnode->setAttribute("offender",$row['offender']);

  $newnode->setAttribute("crime",$row['crime']);

  $newnode->setAttribute("address_no", $row['address_no']);

  $newnode->setAttribute("picaddress", $row['picaddress']);

  $newnode->setAttribute("lat", $row['lat']);

  $newnode->setAttribute("lng", $row['lng']);

  $newnode->setAttribute("type", $row['type']);

}

echo $dom->saveXML();

?>