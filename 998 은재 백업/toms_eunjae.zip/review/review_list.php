<?
  session_start();
  if(!$_SESSION[manager_id]){
    ?>
    <script>
      alert("로그인 하세요.");
      location.replace("../login/login.php");
    </script>
    <?
  } 
?>
<!DOCTYPE html>
<html>
<head>
  <title>화장실 사용후기</title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="../css/main.css" media="all">
  <link rel="stylesheet" type="text/css" href="../css/list.css" media="all">

</head>
 <body>
  <header>
      <?
      include "../lib/top_login2.php"; ?>
      <hr style="border: solid 0.5px #AAABD3;">
      <? include "../lib/top_menu2.php"; ?>
      <hr style="border: solid 0.5px #AAABD3;">
  </header>
    <section id="tom">
      <nav>
      <? include "../lib/left_menu4.php"; ?>
     </nav>
      <center>
    <article>
    <div id="title"> <!--타이틀 나중에 이미지로 넣기-->
      <h2> 화장실 사용후기 </h2>
    </div>  <!-- end of title -->
      <? 
  include "../db_1.php";
  $sql="SELECT * from review_ex";
  $result=mysqli_query($connect, $sql) or die('dsdsds');
  $number=1;  
?>
      <table class="list" cellpadding=2 cellspacing=1>
      <thead>
        <tr class="head">
          <td colspan="4">
            <B> [ 게시판 ] </B></font>
          </td>
          </tr>
          <tr class="head"> 
              
              <td col width="*" class="subject">제목</th>
              <td col width="15%" class="nick">닉네임</th>
              <td col width="20%" class="date">등록일</th>
            </tr>
          </thead>
          <tbody>
          <tr>
            <?
              while($row=mysqli_fetch_array($result)) {
                echo("<tr bgcolor=white align=center >
                    
                    <td>
                    <a href=review_content.php?review_UID=$row[review_UID]>
                    $row[review_title]
                    </a>
                    </td>
                    <td>$row[user_nick]</td>
                    <td>$row[review_date]</td> </tr>");
                $number++;
              }
              mysqli_close($connect);
            ?>
      </table>
      <br><br>
    </article>
  </center>
  </section>

  <footer>Made by TOM( Park Nuri, Park JunMin, Bae Eunjae)</footer>
</body>
</html>
