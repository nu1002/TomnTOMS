<?
  session_start();
?>

<!DOCTYPE html>
<html>
<head>
  <title>화장실 사용후기</title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="../css/main.css" media="all">
  <link rel="stylesheet" type="text/css" href="../css/list.css" media="all">

</head>
<? 
      $date=date("Y-m-d (H:i");
      $connect=mysqli_connect("waytech.kr", "waytechtest", "dnpdl123", "waytechtest");
      mysqli_query ($connect, 'SET NAMES utf8');
      $UID = $_GET["review_UID"];
      $updatesql="UPDATE review_ex Set review_view = review_view+1 where review_UID = $UID";
      $sql="SELECT *from review_ex where review_UID=$UID" ;
      $result=mysqli_query($connect, $sql);
      $row = mysqli_fetch_array($result) or die('x');
      if($row[0]) {
    $number = $row[0]+1;
  }else{
    $number = 1;
  }
      $content = nl2br($row[content]);
?>
 <body>
  <header>
      <? include "../lib/top_login2.php"; ?>
      <hr style="border: solid 0.5px #AAABD3;">
      <? include "../lib/top_menu2.php"; ?>
      <hr style="border: solid 0.5px #AAABD3;">
  </header>
    <section id="tom">
      <nav>
      <? include "../lib/left_menu4.php"; ?>
     </nav>
      <center>
    <article>
    <div id="title"> <!--타이틀 나중에 이미지로 넣기-->
      <h2> 화장실 사용후기 </h2>
    </div>  <!-- end of title -->
    <table class="content" width=650 border=0 cellpadding=2 cellspacing=1 bgcolor=#777777>
      <thead>
        <tr class="head">
          <td colspan="4">
            <B> [ 내용보기 ] </B></font>
          </td>
          </tr>
          </thead>
          <tbody>
          <tr>
            <?
             echo "<table width=650 border= 0 bgcolor=#777777 cellpadding=2 cellspacing=1 >
            <tr>
              <td bgcolor=white>&nbsp;
                <table border=0 bgcolor=#777777 width=643>
              <tr>
                <td width=60 align=left bgcolor=white>제 목</td>
                <td align=left bgcolor=white colspan=3>
                  $row[review_title]
                </td>
              </tr>
              <tr>
                <td width=60 align=left bgcolor=white>화장실</td>
                <td align=left bgcolor=white colspan=3>
                  $row[toilet_name]
                </td>
              </tr>
              <tr>
                <td width=60 align=left bgcolor=white>닉네임</td>
                <td align=left bgcolor=white width=300>
                  $row[user_nick]
                </td>
                <td width=60 align=left bgcolor=white >등록일</td>
                <td align=left bgcolor=white>
                  $row[review_date]
                </td>
              </tr>
              <tr>
                <td width=40 height= 96 align=left bgcolor=white>내용</td>
                <td align=left bgcolor=white colspan=3>
                 $row[review_content]
                </td>
              </tr>
           </table>";
           ?>
    </table>
    <a href=review_list.php>
      <input type="button" value=" 뒤로가기">
    </a>
</article>
  </center>
  </section>
  <footer>Made by TOM( Park Nuri, Park JunMin, Bae Eunjae)
  </footer>
</body>
</html>
