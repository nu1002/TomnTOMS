<?
  session_start();
?>

<!DOCTYPE html>
<html>
<head>
  <title>로그인</title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="../css/main.css" media="all">
  <link rel="stylesheet" type="text/css" href="../css/toms.css" media="all">
</head>
 <body>
  <header>
      <? include "../lib/top_login2.php"; ?>
      <hr style="border: solid 0.5px #AAABD3;">
      <? include "../lib/top_menu2.php"; ?>
      <hr style="border: solid 0.5px #AAABD3;">
  </header>
    <section id="tom">
      <nav>
      <? include "../lib/left_menu1.php"; ?>
     </nav>
      <center>
    <article>
    <div id="title"> <!--타이틀 나중에 이미지로 넣기-->
      <h2>TOMS소개</h2>
    </div>  <!-- end of title -->
    <div id="main_img">
        <img id="toms" src="../img/toilet.PNG" border="0" margin="3">
      </div>
      <div id="intro">
    <p id="intro">      
      Toilet Management System는 화장실관리시스템입니다. <br><br>
      화장실 조회를 통해 관리중인 화장실의 정보와 사용률을 알 수 있습니다. <br><br>
      화장실 사용자의 위급상황도 보다 빨리 발견할 수 있습니다. <br><br>
      화장실 사용시간이 매우 길어지는 칸이 있다면 경고, 위급사항으로 바뀝니다.<br><br>
      <strong>※경고, 위급사항 시 꼭 확인해주시고, 신고 또는 시간초기화를 해주시길 바랍니다.※</strong>

    </p>
    </div>
    </article>
  </center>
  </section>

  <footer>Made by TOM( Park Nuri, Park JunMin, Bae Eunjae)</footer>
</body>
</html>
