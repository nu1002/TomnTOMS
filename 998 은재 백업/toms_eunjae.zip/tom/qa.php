<?
  session_start();
?>

<!DOCTYPE html>
<html>
<head>
  <title>로그인</title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="../css/main.css" media="all">
  <link rel="stylesheet" type="text/css" href="../css/toms.css" media="all">
</head>
 <body>
  <header>
      <? include "../lib/top_login2.php"; ?>
      <hr style="border: solid 0.5px #AAABD3;">
      <? include "../lib/top_menu2.php"; ?>
      <hr style="border: solid 0.5px #AAABD3;">
  </header>
    <section id="tom">
      <nav>
      <? include "../lib/left_menu1.php"; ?>
     </nav>
      <center>
    <article>
    <div id="title"> <!--타이틀 나중에 이미지로 넣기-->
      <h2>Q&A</h2>
    </div>  <!-- end of title -->
    <div id="main_img">
        <img id="qa" src="../img/question.PNG" border="0" margin="3">
      </div>
      <div id="intro">
    <p id="intro">      
      궁금한 점은 <br> <br>
      <strong>TEL ) 010-6235-5117<br> <br>
      E-MAIL ) dmswo96@naver.com <br><br> </strong>로 문의주시면 빠르게 답장해드립니다.

    </p>
    </div>
    </article>
  </center>
  </section>

  <footer>Made by TOM( Park Nuri, Park JunMin, Bae Eunjae)</footer>
</body>
</html>
