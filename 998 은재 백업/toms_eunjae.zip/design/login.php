<!DOCTYPE HTML>
<html>
  <head>
    <title>TOMS</title>
    <meta charset="utf-8" />
    <link rel="stylesheet" href="../css/design.css" />

  </head>
  <body>

    <!-- Header -->
      <header id="header">
        <h1>TOMS에 오신 것을 환영합니다.</h1>
        <p>관리자용 웹페이지입니다. 사용자는 모바일어플을 이용해주시길 바랍니다.</p>
      </header>

    <!-- Signup Form -->
      <form id="signup-form" method="post" action="#">
        <input type="text" name="id" id="id" placeholder="아이디를 입력하세요." />
        <input type="password" name="pw" id="pw" placeholder="비밀번호를 입력하세요." />
        <input type="submit" id="button" value="로그인" />
      </form>

    <!-- Footer -->
      <footer id="footer">Made by TOM( Park Nuri, Park JunMin, Bae Eunjae)</footer>

  </body>
</html>