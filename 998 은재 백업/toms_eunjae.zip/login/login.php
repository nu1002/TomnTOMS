<?
  session_start();
?>

<!DOCTYPE html>
<html>
<head>
  <title>로그인</title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="../css/main_only.css" media="all">
<!--  <script>
    function loginok() //아이디 중복확인
    {
      window.open("login_ok.php?id="+document.login.id.value,"IDcheck","       left=200,top=200,width=200,height=60,scrollbars=no,resizable=yes");
    }

  </script> -->
</head>
 <body>
  <header>
      <? include "../lib/top_login2.php"; ?>
      <hr style="border: solid 0.5px #AAABD3;">
      <? include "../lib/top_menu2.php"; ?>
      <hr style="border: solid 0.5px #AAABD3;">
  </header>
    <section id="login">

      <center>
    <article>
    <form id="signup-form" method="post" action="./login_ok.php">
        아이디 
        <input type="text" name="manager_id" id="id" placeholder="아이디를 입력하세요." />
        비밀번호 
        <input type="password" name="manager_pw" id="pw" placeholder="비밀번호를 입력하세요." />
        <input type="submit" id="button" value="로그인" />
      </form>
    </article>
  </center>
  </section>

  <footer>Made by TOM( Park Nuri, Park JunMin, Bae Eunjae)</footer>
</body>
</html>
