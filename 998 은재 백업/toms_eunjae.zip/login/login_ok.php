<?php
	header("Content-Type: text/html; charset=UTF-8");
	//DB연결	
	include "../db_1.php";
	$query = "SELECT manager_id, manager_name from manager where manager_id='$manager_id' && manager_pw = '$manager_pw'";
	$result = mysqli_query($connect, $query) or die ('Error querying database');

	//이미 로그인한 경우 뒤로 가기
	if($_SESSION[manager_id]){
    ?>
    <script>
        alert("로그인 하신 상태입니다.");
        history.back();
    </script>
    <?
	}

	// 3. 넘어온 변수 검사
if(trim($_POST[manager_id]) == ""){
    ?>
    <script>
        alert("아이디를 입력해 주세요.");
        history.back();
    </script>
    <?
    exit;
}

if($_POST[manager_pw] == ""){
    ?>
    <script>
        alert("비밀번호를 입력해 주세요.");
        history.back();
    </script>
    <?
    exit;
}

// 4. 같은 아이디가 있는지 검사
$chk_sql = "SELECT * from manager where manager_id = '".trim($_POST[manager_id])."'";
$chk_result = mysqli_query($connect, $chk_sql);
$chk_data = mysqli_fetch_array($chk_result);

// 5. 아이디가 존재 하는 경우
if($chk_data[manager_id]){

    // 5. 입력된 비밀번호와 저장된 비밀번호가 같은지 비교해서
    if($_POST[manager_pw] == $chk_data[manager_pw]){
        // 6. 비밀번호가 같으면 세션값 부여 후 이동
        $_SESSION[manager_id] = $chk_data[manager_id];
        $_SESSION[manager_name] = $chk_data[manager_name];

        ?>
        <script>
        alert("환영합니다.");
        location.replace("../main1.php");
        </script>
        <?
        exit;
    }else{
        // 7. 비밀번호가 다르면
        ?>
        <script>
            alert("비밀번호가 다릅니다.");
            history.back();
        </script>
        <?
        exit;
    }
}else{
    // 8. 아이디가 존재하지 않으면
    ?>
    <script>
        alert("존재하지 않는 회원입니다.");
        history.back();
    </script>
    <?
    exit;
}
?>
	