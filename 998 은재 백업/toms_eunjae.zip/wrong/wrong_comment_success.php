<?
  session_start();
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="../css/main.css" media="all">
  <link rel="stylesheet" type="text/css" href="../css/list.css" media="all">


</head>
 <body> 
  <table class="comment" width=650  border=0 margin=5  cellpadding=2 cellspacing=1 bgcolor=#777777>
    <tr>
      <table width=650 border=0 cellpadding=2 cellspacing=1 bgcolor=#777777>
        <td bgcolor=white>&nbsp;
        <table id="comment" >
            <tr>
              <td  width=100 align=left >관리자 답변
              
              <td align=left  >
                
                <?
                  $sql2="SELECT *from comment where wrong_UID=$UID" ;
                  $result2=mysqli_query($connect, $sql2);
                  while($data = mysqli_fetch_array($result2)){
                    
                    $comment = nl2br($data[comment_content]);
                    echo "$comment<br>";
                   
                  }
                ?>
             
              </td>
              </td>
            </tr>
              <tr>
                <td>
                <? 
                while($data = mysqli_fetch_array($result2)){
                    $manager = nl2br($data[comment_content]);
                    echo "$comment"; 

                  }
                ?>
              </td>
              </tr>
              
            </tr>
           </table>
          </td> 
      </table>   
</body>
</html>
