<? 
include "db_1.php";

//답변글이므로 원본의 제목과 내용을 보여주어야 한다.
//thread,depth 값은 저장시에 이용되므로 미리 가져와서 넘겨준다.
$select_parent = mysqli_query("SELECT wrong_UID, comment_order, comment_content from comment where comment_UID=$id",$connect);
$parent_fetch = mysql_fetch_row($select_parent);
$parent_thread = $parent_fetch[0];
$parent_depth = $parent_fetch[1];
$parent_title = $parent_fetch[2];

//아래 부분은 원본 내용에 > 표시를 붙이는 부분이다.
$parent_comment = "\n" . $parent_fetch[3];
$parent_comment = "\n" . str_replace("\n","\n>",$parent_comment);
?>
<html>
<head>
<title>ThreadBoard</title>
<style>
<!--
td { font-size : 9pt; }
A:link { font : 9pt; color : black; text-decoration : none; font-family : 굴림; font-size : 9pt; }
A:visited { text-decoration : none; color : black; font-size : 9pt; }
A:hover { text-decoration : underline; color : black; font-size : 9pt; }

--> 
</style>
</head>

<body topmargin=0 leftmargin=0 text=#464646>

<center>
<BR>

<!-- 입력된 값을 다음 페이지로 넘기기 위해 FORM을 만든다. -->
<form action=insert_reply.php method=post>
<input type=hidden name=parent value=<?=$id?>>
<input type=hidden name=parent_depth value=<?=$parent_depth?>>
<input type=hidden name=parent_thread value=<?=$parent_thread?>>

<table width=580 border=0 cellpadding=2 cellspacing=1 bgcolor=#777777>
<tr>
<td height=20 align=center bgcolor=#999999>
<font color=white><B>글 쓰 기</B></font>
</td>
</tr>

<!-- 입력 부분 -->
<tr>
<td bgcolor=white>&nbsp;
<table>
<tr>
<td width=60 align=left >이름</td>
<td align=left >
<INPUT type=text name=name size=20 maxlength=10>
</td>
</tr>
<tr>
<td width=60 align=left >이메일</td>
<td align=left >
<INPUT type=text name=email size=20 maxlength=25>
</td>
</tr>
<tr>
<td width=60 align=left >비밀번호</td>
<td align=left >
<INPUT type=password name=pass size=8 maxlength=8> (수정,삭제시 반드시 필요)
</td>
</tr>
<tr>
<td width=60 align=left >제 목</td>
<td align=left >
<INPUT type=text name=title size=60 maxlength=35 value="RE:<?=$parent_title?>">
</td>
</tr>
<tr>
<td width=60 align=left >내용</td>
<td align=left >
<TEXTAREA name=comment cols=65 rows=15><?=$parent_comment?></TEXTAREA>
</td>
</tr>
<tr>
<td colspan=10 align=center>
<INPUT type=submit value="글 저장하기">
&nbsp;&nbsp;
<INPUT type=reset value="다시 쓰기">
&nbsp;&nbsp;
<INPUT type=button value="되돌아가기" onclick="history.back(-1)">
</td>
</tr>
</TABLE>
</td> 
</tr>
<!-- 입력 부분 끝 -->
</table>

</center>
</body>
</html>
