<?
  session_start();
?>

<!DOCTYPE html>
<html>
<head>
  <title>시설물 고장신청</title>
  <meta charset="utf-8">
  <link rel="stylesheet" type="text/css" href="../css/main.css" media="all">
  <link rel="stylesheet" type="text/css" href="../css/list.css" media="all">

</head>
<? 
      include "../db_1.php";
      $UID = $_GET["wrong_UID"];
      $updatesql="UPDATE wrong_ex Set wrong_view = wrong_view+1 where wrong_UID = $UID";
      $sql="SELECT *from wrong_ex where wrong_UID=$UID" ;
      $result=mysqli_query($connect, $sql);
      $row = mysqli_fetch_array($result) or die('x');
      if($row[0]) {
    $number = $row[0]+1;
  }else{
    $number = 1;
  }
      $content = nl2br($row[content]);
?>
 <body>
  <header>
      <? include "../lib/top_login2.php"; ?>
      <hr style="border: solid 0.5px #AAABD3;">
      <? include "../lib/top_menu2.php"; ?>
      <hr style="border: solid 0.5px #AAABD3;">
  </header>
    <section id="tom">
      <nav>
      <? include "../lib/left_menu5.php"; ?>
     </nav>
      <center>
    <article>
    <div id="title"> <!--타이틀 나중에 이미지로 넣기-->
      <h2> 시설물 고장신청 </h2>
    </div>  <!-- end of title -->
    <table class="content" width=650 border=0 cellpadding=2 cellspacing=1 bgcolor=#777777>
      <thead>
        <tr class="head">
          <td colspan="4">
            <B> [ 내용보기 ] </B></font>
          </td>
          </tr>
          </thead>
          <tbody>
          <tr>
            <?
             echo "<table width=650 border=0 cellpadding=2 cellspacing=1 bgcolor=#AAABD3>
            <tr>
              <td>
                <table border=0 bgcolor=#777777 width=643>
              <tr>
                <td width=60 align=center bgcolor=white>제 목</td>
                <td align=center bgcolor=white colspan=3>
                	$row[wrong_title]
                </td>
              </tr>
              <tr>
                <td width=60 align=center bgcolor=white>닉네임</td>
                <td align=center bgcolor=white>
                  $row[user_nick]
                </td>
                <td width=60 align=center bgcolor=white>등록일</td>
                <td align=center  width=100 bgcolor=white>
                  $row[wrong_date]
                </td>
              </tr>
              <tr>
                <td width=40 height= 96 align=center bgcolor=white>내용</td>
                <td align=center bgcolor=white colspan=3>
                 $row[wrong_content]
                </td>
              </tr>
           </table>";


        echo
             " 
             <tr>
                <td colspan=4>
                  <B> [ 관리자 댓글 ] </B>
                </td>
              </tr>
              ";
      ?>
      </table>
      <?
        include "wrong_comment_success.php";
        include "wrong_comment.php";

      ?>
</article>
  </center>
  </section>
  <footer>Made by TOM( Park Nuri, Park JunMin, Bae Eunjae)
  </footer>
</body>
</html>
