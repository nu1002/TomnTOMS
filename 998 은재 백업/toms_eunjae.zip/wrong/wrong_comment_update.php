<?    include "../db_1.php";

    $wrong=$_POST["wrong"]; //글번호
    $comment=$_POST["comment"];	
    $manager = $_SESSION["manager_id"];	//작성자 이름    
    $content=$_POST["content"];

    $query = "INSERT into comment (wrong_UID, comment_content, manager_id) values ('$wrong' ,'$content', '$manager')";

    $result = mysqli_query($connect, $query) or die ('Error querying database');

    //$row=mysqli_fetch_array($result);
    header("Content-Type: text/html; charset=UTF-8");
    if($result){        
?> 

    <script>            
        alert('댓글이 정상적으로 작성되었습니다.');           
    </script>        
<?        
    echo "<meta http-equiv='refresh' content='1; URL=wrong_content.php?wrong_UID=$wrong'>";   
    }   

 ?>
