<? session_start();
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	 <link rel="stylesheet" type="text/css" href="../css/main.css" media="all">
  	<link rel="stylesheet" type="text/css" href="../css/list.css" media="all">
	<title></title>
</head>
<body>
		<br/>
	<!-- post로 댓글 등록하기 -->
	<form name="comment" method="post" action="wrong_comment_update.php" style="margin: 0px; padding: 0px;">
	<input type="hidden" name="wrong" value="<? $UID = $_GET["wrong_UID"]; echo "$UID" ?>">
	<table style="width:500px; height:30px; border:0px; margin-left: 0px;">
    	<tr>
        	<td align="left" valign="middle" style="width: 100px; height: 30px; background-color: #AAABD3;">
        	관리자
        	</td>
        	<td align="left" valign="middle" style="width: 460px; height: 30px; border: 1px solid #999999; ">
        	<? 
       			$manager_id = $_SESSION['manager_id'];
       			echo "$manager_id"; 
       		?>	
        	</td>
    	</tr>
    	<tr>
       	 	<td align="left" valign="middle" style="width: 100px; height: 80px; background-color: #AAABD3;">
       	 	글내용
       	 	</td>
       	 	<td align="left" valign="middle" style="width: 400px; height: 80px;">
        	<textarea name="content" style="width: 460px; height: 80px; border: 1px solid #999999;" >
        		<?=$content?>
        	</textarea>
        	</td>
    	</tr>
    <!-- 4. 글쓰기 버튼 클릭시 입력필드 검사 함수 write_save 실행 -->
    	<tr>
        	<td align="center" valign="middle" colspan="2">
            <input type="button" value=" 댓글쓰기 " onClick="write_save();">&nbsp;&nbsp;&nbsp;
        		<a href=wrong_list.php>
            <input type="button" value=" 뒤로가기"></a>
        	</td>
    	</tr>
	</table>
</form>
<script>
	function write_save()
	{
   		// form 을 f 에 지정
    	var f = document.comment;
    	// 입력폼 검사
    	if(f.content.value == " "){
        	alert("글내용을 입력해 주세요.");
        	return false;
    	}
    	// 검사가 성공이면 form 을 submit 한다
    	f.submit();
	}

  function back()
  {
    //리스트로 가기

  }
</script>
</body>
</html>
