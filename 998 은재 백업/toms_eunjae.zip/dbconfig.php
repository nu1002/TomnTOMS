<?
	header("Content-Type: text/html; charset=UTF-8");

	$connect=mysqli_connect("waytech.kr", "waytechtest", "dnpdl123", "waytechtest");
	if ($db -> connect_error) {
		die('데이터베이스 연결에 문제가 있습니다.\n 관리자에게 문의바랍니다.');

		$db -> set_charset('utf-8');
		# code...
	}
	//or die("SQL server에 연결할 수 없습니다.");
	//if (mysqli_connect_errno($connect)) {
	//	echo "db fail";
	//}
	//else{
	//	echo "db success";
	//}
//	mysql_select_db("toms",$connect);
//	$query = "INSERT INTO user ( user_id, user_pw, user_nick, user_sex) VALUES('값','값','값','값')";
//	$query = "SELECT * FROM user";   //db select문	
	   

//	$result = mysqli_query($connect, $query) or die('X');
//	mysqli_close($connect);         //DB 연결 종료
?>