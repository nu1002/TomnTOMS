<?
	session_start();
	if(isset($_SESSION['manager_id'])) {
		echo "<meta http-equiv='refresh' content='0;url=index.php'>";
		exit;
		}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/main_only.css">
</head>
<body>
	<header>
		<?include "./lib/top_login.php";?>
		<hr style="border: solid 0.5px #AAABD3;">
		<?include "./lib/top_menu.php";?>
		<hr style="border: solid 0.5px #AAABD3;">
	</header>
	<section id="main">
		<!-- Header -->
      <header id="header">
		<img id="hello" src="../img/hello.png" border="0" padding-bottom="10">	
       	<p id="alarm">"이곳은 <strong>관리자용</strong> 페이지입니다." <br> </p>

       	<p id="alarm1">사용자는 모바일 어플을 이용해주시길 바랍니다.</p>
      </header>

    <!-- Signup Form -->
    <!-- 여기에 로고 들어가면 좋을 것 같다 -->
    <!-- ./login/login.php로 이동하는 버튼도 -->

      <div>
      	<p id="login"><a href="./login/login.php">로그인 하러 가기</a></p>
      </div>
      
	</section>
	<footer>Made by TOM( Park Nuri, Park JunMin, Bae Eunjae)</footer>
</body>
</html>