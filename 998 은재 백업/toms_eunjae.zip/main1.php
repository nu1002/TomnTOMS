<?
	session_start();
	if(!isset($_SESSION['manager_id']) || !isset($_SESSION['manager_name'])) {
		echo "<meta http-equiv='refresh' content='0;url=./login/login.php'>";
		exit;
		}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="css/main_only.css">
</head>
<body>
	<header>
		<?include "./lib/top_login.php";?>
		<hr style="border: solid 0.5px #AAABD3;">
		<?include "./lib/top_menu.php";?>
		<hr style="border: solid 0.5px #AAABD3;">
	</header>
	<section id="main">
		<header id="header">
			<img id="hello" src="../img/hello.png" border="0">
       	<p id="alarm">"이곳은 <strong>관리자용</strong> 페이지입니다." <br> </p>

       	<?php
       		$manager_id = $_SESSION['manager_id'];
			$manager_name = $_SESSION['manager_name'];
       		echo "<p>안녕하세요. <b>$manager_name($manager_id)님</b></p>";
       	?>
      </header>

		<form id="logout-form" method="post" action="./login/logout.php">
        <input type="submit" id="button" value="로그아웃" />
      </form>
	</section>
	<footer>Made by TOM( Park Nuri, Park JunMin, Bae Eunjae)</footer>
</body>
</html>