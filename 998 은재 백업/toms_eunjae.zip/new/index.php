<!DOCTYPE html>
<html>
<head>
	<title>Main</title>
	<meta charset="utf-8">
</head>
<body>
		<h1>TOMS를 이용해주셔서 감사합니다.</h1>
		<?php
			if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_nick'])) {
				echo "<p>로그인을 해주세요. <a href=\"login.php\"> [로그인] </a> </p>";
			}	else {
				$user_id = $_SESSION['user_id'];
				$user_nick = $_SESSION['user_nick'];
				echo "<p><strong>$user_nick</strong>($user_id)님 환영합니다.";
				echo "<a href =\"logout.php\"> [로그아웃] </a> </p> ";
			}
		?>
		<hr />
		<p> 이 페이지는 관리자용 페이지입니다.</p>

</body>
</html>