<?php
	if (!isset($_POST['user_id']) || !isset($_POST['user_pw']) ) {
		header("Content-Type: text/html; charset=UTF-8");
		echo "<script> alert('아이디 또는 비밀번호를 입력하세요.')";
		echo "window.location.replace('login.php');</script>";
		exit;
		
	}
	$user_id = $_POST['user_id'];
	$user_pw = $_POST['user_pw'];
	$members = array(
		'kpuadminA' => array('password' => '123456789', 'nick' => '한국산업기술대학교 공학관 A동 관리자'),
		'kpuadminB' => array('password' => '123456789', 'nick' => '한국산업기술대학교 공학관 B동 관리자'),
		'kpuadminC' => array('password' => '123456789', 'nick' => '한국산업기술대학교 공학관 C동 관리자'),
		'kpuadminD' => array('password' => '123456789', 'nick' => '한국산업기술대학교 공학관 D동 관리자')
	);
	if (!isset($members[$user_id]) || $members[$user_id]['password'] != $user_pw ) { 
		header("Content-Type: text.html; charset=UTF-8");
		echo "<script>alert('아이디 또는 비밀번호가 잘못되었습니다.');"; 
		echo "window.location.replace('login.php'); </script>";
		exit;
	}

	session_start();
	$_SESSION['user_id'] = $user_id;
	$_SESSION['user_nick'] = $members[$user_id]['nick'];

?>
<meta http-equiv="refresh" content="0;url=index.php">