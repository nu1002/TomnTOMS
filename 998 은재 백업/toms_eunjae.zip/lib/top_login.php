<div class="top">
	<a href="../main.php">
		<img id="logo" src="../img/logo1.png" border="0">
	</a>
</div>
