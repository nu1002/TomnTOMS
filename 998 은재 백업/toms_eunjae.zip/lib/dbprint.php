<?
	header("Content-Type: text/html; charset=UTF-8");
	$connect=mysqli_connect("localhost", "toms", "passwd", "toms");
	//if else문 대신 or die문 추가해도 됨 or die('Error connectiong to MySQL server')
	//db 연결 확인
	if(mysqli_connect_errno($connect)){
	   echo "DB fail";
	}
	else{
   		echo "DB success";
	}
	echo'<br>';

	$query = "SELECT * FROM user";   //db select문	
	$result = mysqli_query($connect, $query) or die ('Error querying database');   

	//db 출력
	while($row = mysqli_fetch_array($result)){
  		echo "talbe1: ".$row[user_id].", table2: ".$row[user_nick];
  		echo "<br>";

	}

	mysqli_free_result($result);
	mysqli_close($connect);

	
?>