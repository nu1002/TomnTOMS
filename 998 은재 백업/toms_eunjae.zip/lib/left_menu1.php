
<div class="left_menu">
	<a href="../tom/toms.php">
		<p>TOMS소개</p>
	</a>
</div>
<div class="left_menu">
	<a href="../tom/tom.php">
		<p>TOM소개</p>
	</a>
</div>
<div class="left_menu">
	<a href="../tom/qa.php">
		<p>Q&A</p>
	</a>
</div>
