
<div class="left_menu">
	<a href="../wrong/wrong_list.php">
		<p>고장신청목록</p>
	</a>
</div>
<!-- <div class="left_menu">
	<a href="../wrong/wrong_ing.php">
		<p>진행중인 신청</p>
	</a>
</div>
<div class="left_menu">
	<a href="../wrong/wrong_complete.php">
		<p>완료된 신청</p>
	</a>
</div> -->
