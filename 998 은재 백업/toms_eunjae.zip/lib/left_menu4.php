
<div class="left_menu">
	<a href="../review/review_list.php">
		<p>사용후기목록</p>
	</a>
</div>
<!-- <div class="left_menu">
	<a href="../review/review_my.php">
		<p>내 화장실후기</p>
	</a>
</div>
<div class="left_menu">
	<a href="../review/review_reply.php">
		<p>내가 쓴 댓글</p>
	</a>
</div> -->
