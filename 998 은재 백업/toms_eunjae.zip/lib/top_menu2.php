
<div class="menus">
	<a href="../tom/toms.php">
		TOMS소개
	</a>
</div>
<div class="menus">
	<a href="../toilet/use.php">
		사용률 조회
	</a>
</div>
<div class="menus">
	<a href="../toilet/clean_list.php">
		점검표 조회
	</a>
</div>
<div class="menus">
	<a href="../review/review_list.php">
		화장실 후기
	</a>
</div>
<div class="menus">
	<a href="../wrong/wrong_list.php">
		시설물 고장
	</a>
</div>