<div class="left_menu">
	<a href="../toilet/clean_list.php">
		<p>청소 점검표</p>
	</a>
</div>
<div class="left_menu">
	<a href="../toilet/manage_list.php">
		<p>시설 점검표</p>
	</a>
</div>
<div class="left_menu">
	<a href="../toilet/item_list.php">
		<p>비품 대장</p>
	</a>
</div>