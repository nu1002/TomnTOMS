

<div class="left_menu">
	<a href="../toilet/use.php">
		<p>사용률 조회</p>
	</a>
</div>
<div class="left_menu">
	<a href="../toilet/graph1.php">
		<p>날짜별 사용률</p>
	</a>
</div>
<div class="left_menu">
	<a href="../toilet/graph2.php">
		<p>시간별 사용률</p>
	</a>
</div>
